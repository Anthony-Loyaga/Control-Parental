package com.example.controlparental.Parent.Model

data class ChildData(
    val id: String = "",
    val name: String = "",
    val totalAppsToday: Int = 0,
    val deviceName: String = "",
    val deviceActive: Boolean = false,
    val battery: Int = -1,
    val latitude: Double? = null,
    val longitude: Double? = null
)