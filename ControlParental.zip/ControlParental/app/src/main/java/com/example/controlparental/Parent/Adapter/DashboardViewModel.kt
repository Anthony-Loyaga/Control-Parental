package com.example.controlparental.Parent.Adapter

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.controlparental.Parent.Model.ChildData
import com.google.firebase.firestore.FirebaseFirestore

class DashboardViewModel : ViewModel() {

    private val db = FirebaseFirestore.getInstance()
    private val _data = MutableLiveData<ChildData>()
    val data: LiveData<ChildData> get() = _data

    fun loadDashboard(childId: String) {
        val childRef = db.collection("children").document(childId)

        childRef.get().addOnSuccessListener { childDoc ->
            if (!childDoc.exists()) return@addOnSuccessListener

            val childName = childDoc.getString("name") ?: "Niño"
            val totalApps = if (childDoc.contains("totalTimeUsedToday")) {
                childDoc.getLong("totalTimeUsedToday")?.toInt() ?: 0
            } else 0

            // ----------- DISPOSITIVOS -----------
            childRef.collection("devices").get()
                .addOnSuccessListener { deviceSnap ->

                    var deviceName = "Sin dispositivo"
                    var deviceActive = false

                    for (d in deviceSnap) {
                        deviceName = d.getString("deviceName") ?: deviceName
                        deviceActive = d.getBoolean("isActive") ?: false
                        break
                    }

                    // ----------- UBICACIÓN -----------
                    childRef.collection("location")
                        .document("current")
                        .get()
                        .addOnSuccessListener { loc ->
                            val battery = loc.getLong("batteryLevel")?.toInt() ?: -1
                            val lat = loc.getDouble("latitude")
                            val lon = loc.getDouble("longitude")

                            val childData = ChildData(
                                id = childId,
                                name = childName,
                                totalAppsToday = totalApps,
                                deviceName = deviceName,
                                deviceActive = deviceActive,
                                battery = battery,
                                latitude = lat,
                                longitude = lon
                            )

                            _data.postValue(childData)
                        }
                }
        }
    }
}