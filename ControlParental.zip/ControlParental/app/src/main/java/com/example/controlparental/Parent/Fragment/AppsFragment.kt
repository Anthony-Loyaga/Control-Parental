package com.example.controlparental.Parent.Fragment


import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.Parent.Adapter.AppListAdapter
import com.example.controlparental.Parent.ViewModel.ParentalActionsViewModel
import com.example.controlparental.R
import com.example.controlparental.entidad.AppItem
import com.google.android.material.card.MaterialCardView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration

class AppsFragment : Fragment() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var parentId: String

    private var selectedChildId: String? = null
    private lateinit var appListAdapter: AppListAdapter
    private lateinit var recyclerView: RecyclerView
    private lateinit var childrenContainer: LinearLayout
    private lateinit var summaryContainer: LinearLayout
    private lateinit var tvAppCount: TextView
    private lateinit var tvTotalUsage: TextView
    private var appsListener: ListenerRegistration? = null
    private val vm: ParentalActionsViewModel by activityViewModels()
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        return inflater.inflate(R.layout.fragment_apps, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        parentId = auth.currentUser?.uid ?: return

        // Inicializar vistas
        recyclerView = view.findViewById(R.id.recyclerViewApps)
        recyclerView.layoutManager = LinearLayoutManager(context)
        childrenContainer = view.findViewById(R.id.childrenContainer)
        summaryContainer = view.findViewById(R.id.summaryContainer)
        tvAppCount = view.findViewById(R.id.tvAppCount)
        tvTotalUsage = view.findViewById(R.id.tvTotalUsage)

        appListAdapter = AppListAdapter(
            onToggle = { packageName, isBlocked ->
                toggleAppBlockStatus(packageName, isBlocked)
            },
            onAppClick = { packageName ->
                openTimeLimitDialog(packageName)
            }
        )
        recyclerView.adapter = appListAdapter
        val etSearch = view.findViewById<EditText>(R.id.etSearchApp)

        etSearch.addTextChangedListener { text ->
            appListAdapter.filter(text.toString())
        }
        // Cargar lista de hijos
        loadChildren()
        vm.unblockApp.observe(viewLifecycleOwner) { guess ->
            guess?.let { nameOrPkg ->
                val app = appListAdapter.findByNameOrPackage(nameOrPkg)
                if (app != null && selectedChildId != null) {
                    toggleAppBlockStatus(app.packageName, false)
                    Toast.makeText(context, "App desbloqueada: ${app.name}", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "No encontré la app para desbloquear: $nameOrPkg", Toast.LENGTH_SHORT).show()
                }
            }
        }


        vm.setLimit.observe(viewLifecycleOwner) { pair ->
            pair?.let { (nameOrPkg, minutes) ->
                val app = appListAdapter.findByNameOrPackage(nameOrPkg)
                if (app != null && selectedChildId != null) {
                    updateTimeLimit(app.packageName, minutes)
                } else {
                    Toast.makeText(context, "No encontré la app para límite: $nameOrPkg", Toast.LENGTH_SHORT).show()
                }
            }
        }


        vm.selectChild.observe(viewLifecycleOwner) { childName ->
            childName?.let { name ->
// Buscar childId por nombre (simple consulta). Asume nombres únicos o muestra primer match
                db.collection("users").whereEqualTo("name", name).get()
                    .addOnSuccessListener { snapshot ->
                        if (!snapshot.isEmpty) {
                            val doc = snapshot.documents[0]
                            selectChild(doc.id)
                        } else {
                            Toast.makeText(context, "No encontré hijo: $name", Toast.LENGTH_SHORT).show()
                        }
                    }
                    .addOnFailureListener { e ->
                        Toast.makeText(context, "Error al seleccionar hijo: ${e.message}", Toast.LENGTH_SHORT).show()
                    }
            }
        }
    }

    private fun loadChildren() {
        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .whereEqualTo("status", "active")
            .get()
            .addOnSuccessListener { snapshot ->
                childrenContainer.removeAllViews()
                if (snapshot.isEmpty) return@addOnSuccessListener

                for (doc in snapshot) {
                    val childId = doc.getString("childId") ?: continue
                    db.collection("users").document(childId)
                        .get()
                        .addOnSuccessListener { userDoc ->
                            val name = userDoc.getString("name") ?: "Hijo"
                            addChildCard(childId, name)
                        }
                        .addOnFailureListener {
                            addChildCard(childId, "Hijo")
                        }
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(context, "Error al cargar hijos: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun addChildCard(childId: String, childName: String) {
        val inflater = LayoutInflater.from(context)
        val itemView = inflater.inflate(R.layout.item_hijo, childrenContainer, false)

        itemView.findViewById<TextView>(R.id.tvChildName).text = childName
        itemView.setOnClickListener {
            selectChild(childId)
            // Resaltar tarjeta seleccionada
            (itemView as MaterialCardView).strokeWidth = 4
            // Opcional: des-resaltar otras tarjetas
            for (i in 0 until childrenContainer.childCount) {
                val child = childrenContainer.getChildAt(i)
                if (child != itemView) {
                    (child as MaterialCardView).strokeWidth = 0
                }
            }
        }

        childrenContainer.addView(itemView)
    }

    private fun selectChild(childId: String) {
        // Evitar recarga innecesaria si es el mismo hijo
        if (selectedChildId == childId) return

        selectedChildId = childId
        loadAppsForChild(childId)
        summaryContainer.visibility = View.VISIBLE
    }

    private fun loadAppsForChild(childId: String) {
        // ✅ Cancelar listener anterior si se cambia de hijo
        appsListener?.remove()

        appsListener = db.collection("children/$childId/apps")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Toast.makeText(context, "Error: ${error.message}", Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }

                if (snapshot == null) return@addSnapshotListener

                val apps = mutableListOf<AppItem>()
                var totalUsage = 0

                for (doc in snapshot.documents) {
                    val data = doc.data ?: continue

                    val usageToday = (data["timeUsedToday"] as? Long)?.toInt() ?: 0
                    totalUsage += usageToday

                    apps.add(
                        AppItem(
                            packageName = doc.id,
                            name = data["name"] as? String ?: "App",
                            category = data["category"] as? String ?: "General",
                            timeUsedToday = usageToday,
                            todayUsageMinutes = usageToday,

                            isBlocked = data["isBlocked"] as? Boolean ?: false,
                            isActive = data["isActive"] as? Boolean ?: false,

                            lastActive = data["lastActive"] as? Long ?: 0L,
                            lastUsageUpdate = data["lastUsageUpdate"] as? Long ?: 0L,

                            timeLimitMinutes = (data["timeLimitMinutes"] as? Long)?.toInt() ?: 0
                        )
                    )
                }

                // ✅ Cargar iconos y actualizar adaptador
                loadIconsFromAppIconsCollection(apps) { appsWithIcons ->
                    appListAdapter.updateApps(appsWithIcons)
                    tvAppCount.text = appsWithIcons.size.toString()
                    tvTotalUsage.text = "${totalUsage}m"
                }
            }
    }

    private fun loadIconsFromAppIconsCollection(apps: List<AppItem>, onComplete: (List<AppItem>) -> Unit) {
        if (apps.isEmpty()) {
            onComplete(apps)
            return
        }

        val updatedApps = apps.toMutableList()
        var completed = 0
        val total = apps.size

        for ((index, app) in apps.withIndex()) {
            db.collection("app_icons").document(app.packageName).get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val iconUrl = document.getString("iconUrl")
                        val category = document.getString("category") ?: app.category
                        updatedApps[index] = app.copy(iconUrl = iconUrl, category = category)
                    }
                }
                .addOnFailureListener { /* ignora */ }
                .addOnCompleteListener {
                    completed++
                    if (completed == total) {
                        onComplete(updatedApps)
                    }
                }
        }
    }

    private fun toggleAppBlockStatus(packageName: String, isBlocked: Boolean) {
        selectedChildId?.let { childId ->
            appListAdapter.updateAppStatus(packageName, isBlocked)
            db.collection("children/$childId/apps").document(packageName)
                .update("isBlocked", isBlocked)
                .addOnFailureListener { e ->
                    appListAdapter.updateAppStatus(packageName, !isBlocked)
                    Toast.makeText(context, "Error al actualizar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Toast.makeText(context, "Selecciona un hijo primero.", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openTimeLimitDialog(packageName: String) {
        selectedChildId?.let { childId ->
            db.collection("children/$childId/apps").document(packageName)
                .get()
                .addOnSuccessListener { document ->
                    val currentLimit = document.getLong("timeLimitMinutes")?.toInt() ?: 0
                    TimeLimitDialogFragment.Companion.newInstance(packageName, currentLimit)
                        .show(childFragmentManager, "TimeLimitDialog")
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Error al cargar límite: ${e.message}", Toast.LENGTH_SHORT).show()
                    TimeLimitDialogFragment.Companion.newInstance(packageName, 0)
                        .show(childFragmentManager, "TimeLimitDialog")
                }
        }
    }

    private fun updateTimeLimit(packageName: String, minutes: Int) {
        selectedChildId?.let { childId ->
            db.collection("children/$childId/apps").document(packageName)
                .update("timeLimitMinutes", minutes)
                .addOnSuccessListener {
                    Toast.makeText(context, "Límite guardado", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(context, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        } ?: run {
            Toast.makeText(context, "Selecciona un hijo primero.", Toast.LENGTH_SHORT).show()
        }
    }
}