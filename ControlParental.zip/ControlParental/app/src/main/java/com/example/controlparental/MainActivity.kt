package com.example.controlparental
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.controlparental.Parent.LoginActivity
import com.example.controlparental.children.ChildLandingActivity
import com.google.android.material.card.MaterialCardView
import com.google.ai.client.generativeai.GenerativeModel
import androidx.core.view.WindowCompat
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Obtener referencias a las cards
        val cardParent = findViewById<MaterialCardView>(R.id.cardParent)
        val cardChild = findViewById<MaterialCardView>(R.id.cardChild)

        // Configurar click listeners
        cardParent.setOnClickListener {
            // Aquí irá la lógica para padres
            Toast.makeText(this, "Modo Padre/Madre seleccionado", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        cardChild.setOnClickListener {
            // Aquí irá la lógica para hijos
            Toast.makeText(this, "Modo Hijo/Hija seleccionado", Toast.LENGTH_SHORT).show()
            val intent = Intent(this, ChildLandingActivity::class.java)
            startActivity(intent)
        }
    }
}