package com.example.controlparental.Parent.Fragments

import android.content.Context
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.controlparental.Parent.Adapter.ChatAdapter
import com.example.controlparental.Parent.Adapter.ChatMessage
import com.example.controlparental.databinding.FragmentChatbotBinding
import com.example.controlparental.utils.SessionManager
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.Content
import com.google.ai.client.generativeai.type.content
import com.google.ai.client.generativeai.type.generationConfig
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import org.json.JSONObject

class ChatBotFragment : Fragment() {
    private val conversationHistory = mutableListOf<Content>()
    private var _binding: FragmentChatbotBinding? = null
    private val binding get() = _binding!!

    private lateinit var gemini: GenerativeModel
    private lateinit var chatAdapter: ChatAdapter

    private val messages = mutableListOf<ChatMessage>()
    private val db = FirebaseFirestore.getInstance()

    private var parentId: String? = null

    private val childrenMap = mutableMapOf<String, String>()
    private val childrenApps = mutableMapOf<String, MutableList<Map<String, Any>>>()

    private val TAG = "CHATBOT_AI"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentChatbotBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Cargar el ID del padre desde SessionManager
        parentId = SessionManager.getParentId(requireContext())

        // Inicializar adapter y RecyclerView
        chatAdapter = ChatAdapter(messages)
        binding.recyclerChat.layoutManager = LinearLayoutManager(requireContext())
        binding.recyclerChat.adapter = chatAdapter

        if (parentId == null) {
            chatAdapter.addMessage("AI", "Debes iniciar sesión de nuevo.")
        }

        // Inicializar Gemini 2.5
        val apiKey = getGeminiApiKey(requireContext())
        gemini = GenerativeModel(
            modelName = "gemini-2.5-flash",
            apiKey = apiKey,
            generationConfig = generationConfig { temperature = 0.3f }
        )

        // Cargar hijos automáticamente (asíncrono)
        loadChildren()

        binding.btnSend.setOnClickListener {
            val msg = binding.etMessage.text.toString().trim()
            if (msg.isNotEmpty()) {
                binding.etMessage.setText("")
                chatAdapter.addMessage("Yo", msg)
                sendMessageToGemini(msg)
            }
        }
    }

    // --------------------------------------------------------------------------------------------
    // LECTURA DE API KEY DESDE META-DATA
    // --------------------------------------------------------------------------------------------
    private fun getGeminiApiKey(context: Context): String {
        val appInfo = context.packageManager.getApplicationInfo(
            context.packageName,
            PackageManager.GET_META_DATA
        )
        return appInfo.metaData.getString("GEMINI_API_KEY") ?: ""
    }

    // --------------------------------------------------------------------------------------------
    // CARGAR HIJOS DEL PADRE
    // --------------------------------------------------------------------------------------------
    private fun loadChildren() {
        if (parentId == null) return

        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .whereEqualTo("status", "active")
            .get()
            .addOnSuccessListener { snapshot ->

                for (doc in snapshot.documents) {
                    val childId = doc.getString("childId") ?: continue

                    db.collection("users").document(childId)
                        .get()
                        .addOnSuccessListener { userDoc ->
                            val name = userDoc.getString("name") ?: "hijo"
                            childrenMap[name.lowercase()] = childId

                            Log.d(TAG, "Hijo cargado: $name -> $childId")

                            loadApps(childId)
                        }
                }
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error cargando guardianships: ${e.message}", e)
            }
    }

    // --------------------------------------------------------------------------------------------
    // CARGAR APPS POR HIJO
    // --------------------------------------------------------------------------------------------
    private fun loadApps(childId: String) {
        db.collection("children/$childId/apps")
            .get()
            .addOnSuccessListener { snap ->

                val apps = mutableListOf<Map<String, Any>>()

                for (doc in snap.documents) {
                    val data = doc.data ?: continue
                    apps.add(
                        mapOf(
                            "package" to doc.id,
                            "name" to (data["name"] ?: ""),
                            "blocked" to (data["isBlocked"] ?: false)
                        )
                    )
                }

                childrenApps[childId] = apps

                Log.d(TAG, "Apps de $childId cargadas: $apps")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error cargando apps de $childId: ${e.message}", e)
            }
    }

    // --------------------------------------------------------------------------------------------
    // ENVIAR CONSULTA A GEMINI (suspend dentro de lifecycleScope)
    // --------------------------------------------------------------------------------------------
    private fun sendMessageToGemini(msg: String) {
        lifecycleScope.launch {

            val contexto = buildContext()

            val prompt = """
            Eres un asistente de control parental.

            Debes responder SIEMPRE en JSON:
            {
                "Texto": "respuesta natural",
                "json": {
                    "intent": "block_app | unblock_app | set_time_limit | get_child_apps",
                    "childName": "",
                    "childId": "",
                    "appName": "",
                    "packageName": "",
                    "timeLimitMinutes": 0
                }
            }

            CONTEXTO DEL USUARIO:
            $contexto

            NUEVO MENSAJE:
            $msg
        """.trimIndent()

            try {

                // 👉 1. Guardar mensaje del usuario en historial
                conversationHistory.add(
                    content { text("Usuario: $prompt") }
                )

                // 👉 2. Llamada a Gemini con historial incluido
                val response = gemini.generateContent(
                    *conversationHistory.toTypedArray()
                )

                val raw = response.text ?: ""
                val cleaned = raw
                    .replace("```json", "")
                    .replace("```", "")
                    .trim()

                Log.d(TAG, "RAW: $raw")
                Log.d(TAG, "CLEAN: $cleaned")

                // 👉 3. Guardar respuesta de la IA en historial
                conversationHistory.add(
                    content { text("AI: $cleaned") }
                )

                // 👉 4. Procesar JSON si existe
                val json = extractJson(cleaned)
                if (json != null) {
                    processJSON(json)
                } else {
                    chatAdapter.addMessage("AI", cleaned)
                }

            } catch (e: Exception) {
                Log.e(TAG, "Error llamando a Gemini: ${e.message}", e)
                chatAdapter.addMessage("AI", "Error del asistente: ${e.message}")
            }
        }
    }



    // --------------------------------------------------------------------------------------------
    // CONSTRUYE EL CONTEXTO PARA GEMINI
    // --------------------------------------------------------------------------------------------
    private fun buildContext(): String {
        val sb = StringBuilder()

        for ((name, id) in childrenMap) {
            sb.append("Hijo: $name -> ID: $id\n")

            val apps = childrenApps[id]
            if (!apps.isNullOrEmpty()) {
                sb.append("Apps:\n")
                for (app in apps) {
                    sb.append("- ${app["name"]} (package=${app["package"]})\n")
                }
            } else {
                sb.append("Apps: ninguna\n")
            }
            sb.append("\n")
        }

        return sb.toString()
    }

    // --------------------------------------------------------------------------------------------
    // PROCESAR JSON DE GEMINI (AHORA INCLUYE UNBLOCK)
    // --------------------------------------------------------------------------------------------
    private fun processJSON(json: JSONObject) {

        val text = json.optString("Texto")
        if (text.isNotEmpty()) chatAdapter.addMessage("AI", text)

        val action = json.optJSONObject("json") ?: return

        val intent = action.optString("intent")
        val childId = action.optString("childId")
        val pkg = action.optString("packageName")
        val minutes = action.optInt("timeLimitMinutes")

        when (intent) {
            "block_app" -> {
                if (childId.isNotEmpty() && pkg.isNotEmpty()) blockApp(childId, pkg)
                else chatAdapter.addMessage("AI", "Falta childId o packageName para bloquear.")
            }

            "unblock_app" -> {
                if (childId.isNotEmpty() && pkg.isNotEmpty()) unblockApp(childId, pkg)
                else chatAdapter.addMessage("AI", "Falta childId o packageName para desbloquear.")
            }

            "set_time_limit" -> {
                if (childId.isNotEmpty() && pkg.isNotEmpty()) setTimeLimit(childId, pkg, minutes)
                else chatAdapter.addMessage("AI", "Falta childId o packageName para poner límite.")
            }

            "get_child_apps" -> {
                if (childId.isNotEmpty()) listApps(childId)
                else chatAdapter.addMessage("AI", "Falta childId para listar apps.")
            }

            else -> {
                // si intent = none o desconocido, solo muestra texto (ya hecho arriba)
            }
        }
    }

    // --------------------------------------------------------------------------------------------
    // FIRESTORE - Bloquear app
    // --------------------------------------------------------------------------------------------
    private fun blockApp(childId: String, pkg: String) {
        if (childId.isEmpty() || pkg.isEmpty()) return

        db.document("children/$childId/apps/$pkg")
            .update("isBlocked", true)
            .addOnSuccessListener {
                chatAdapter.addMessage("AI", "Listo, la app ha sido bloqueada.")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error bloqueando app: ${e.message}", e)
                chatAdapter.addMessage("AI", "Error bloqueando la app: ${e.message}")
            }
    }

    // --------------------------------------------------------------------------------------------
    // FIRESTORE - Desbloquear app (NUEVO)
    // --------------------------------------------------------------------------------------------
    private fun unblockApp(childId: String, pkg: String) {
        if (childId.isEmpty() || pkg.isEmpty()) return

        db.document("children/$childId/apps/$pkg")
            .update("isBlocked", false)
            .addOnSuccessListener {
                chatAdapter.addMessage("AI", "He desbloqueado la app correctamente.")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error desbloqueando app: ${e.message}", e)
                chatAdapter.addMessage("AI", "Error desbloqueando la app: ${e.message}")
            }
    }

    // --------------------------------------------------------------------------------------------
    // FIRESTORE - Limitar tiempo
    // --------------------------------------------------------------------------------------------
    private fun setTimeLimit(childId: String, pkg: String, minutes: Int) {
        if (childId.isEmpty() || pkg.isEmpty()) return

        db.document("children/$childId/apps/$pkg")
            .update("timeLimitMinutes", minutes)
            .addOnSuccessListener {
                chatAdapter.addMessage("AI", "Límite de tiempo actualizado.")
            }
            .addOnFailureListener { e ->
                Log.e(TAG, "Error actualizando límite: ${e.message}", e)
                chatAdapter.addMessage("AI", "Error actualizando límite: ${e.message}")
            }
    }

    // --------------------------------------------------------------------------------------------
    // FIRESTORE - Listar apps del niño
    // --------------------------------------------------------------------------------------------
    private fun listApps(childId: String) {
        val apps = childrenApps[childId]
        if (apps.isNullOrEmpty()) {
            chatAdapter.addMessage("AI", "Ese niño no tiene apps registradas.")
            return
        }

        val text = apps.joinToString("\n") { "- ${it["name"]}" }
        chatAdapter.addMessage("AI", "Las apps de este niño son:\n$text")
    }

    // --------------------------------------------------------------------------------------------
    // EXTRAER JSON DE LA RESPUESTA
    // --------------------------------------------------------------------------------------------
    private fun extractJson(text: String): JSONObject? =
        try { JSONObject(text) }
        catch (_: Exception) {
            try {
                val s = text.indexOf("{")
                val e = text.lastIndexOf("}")
                if (s >= 0 && e > s) JSONObject(text.substring(s, e + 1)) else null
            } catch (_: Exception) {
                null
            }
        }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
