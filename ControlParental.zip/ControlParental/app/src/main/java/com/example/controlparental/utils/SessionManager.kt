package com.example.controlparental.utils

import android.content.Context

object SessionManager {

    private const val PREF_NAME = "parent_session"
    private const val KEY_PARENT_ID = "parent_id"
    private const val KEY_USER_EMAIL = "user_email"
    private const val KEY_USER_NAME = "user_name"
    private const val KEY_IS_LOGGED_IN = "is_logged_in"
    private const val KEY_ROLE = "role"

    fun saveParentId(context: Context, parentId: String) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putString(KEY_PARENT_ID, parentId).apply()
    }

    fun getParentId(context: Context): String? {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return pref.getString(KEY_PARENT_ID, null)
    }

    // Nuevas funciones agregadas
    fun saveUserEmail(context: Context, email: String) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putString(KEY_USER_EMAIL, email).apply()
    }

    fun getUserEmail(context: Context): String? {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return pref.getString(KEY_USER_EMAIL, null)
    }

    fun saveUserName(context: Context, name: String) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putString(KEY_USER_NAME, name).apply()
    }

    fun getUserName(context: Context): String? {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return pref.getString(KEY_USER_NAME, null)
    }

    fun setLoggedIn(context: Context, isLoggedIn: Boolean) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).apply()
    }

    fun isLoggedIn(context: Context): Boolean {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return pref.getBoolean(KEY_IS_LOGGED_IN, false)
    }

    fun saveRole(context: Context, role: String) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().putString(KEY_ROLE, role).apply()
    }

    fun getRole(context: Context): String? {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return pref.getString(KEY_ROLE, null)
    }

    fun isParent(context: Context): Boolean {
        return getRole(context) == "parent"
    }

    fun isChild(context: Context): Boolean {
        return getRole(context) == "child"
    }

    // Función para guardar todos los datos del usuario de una vez
    fun saveUserData(context: Context, parentId: String, email: String, name: String, role: String) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().apply {
            putString(KEY_PARENT_ID, parentId)
            putString(KEY_USER_EMAIL, email)
            putString(KEY_USER_NAME, name)
            putString(KEY_ROLE, role)
            putBoolean(KEY_IS_LOGGED_IN, true)
        }.apply()
    }

    // Función para obtener todos los datos del usuario
    fun getUserData(context: Context): Map<String, String?> {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return mapOf(
            "parentId" to pref.getString(KEY_PARENT_ID, null),
            "email" to pref.getString(KEY_USER_EMAIL, null),
            "name" to pref.getString(KEY_USER_NAME, null),
            "role" to pref.getString(KEY_ROLE, null)
        )
    }

    fun clear(context: Context) {
        val pref = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        pref.edit().clear().apply()
    }
}