package com.example.controlparental.children.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.app.usage.UsageStatsManager
import android.content.Intent
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.controlparental.MainActivity
import com.example.controlparental.R
import com.example.controlparental.children.AppBlockedActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.HashSet
import java.util.Locale

class AppBlockerService : Service() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var handler: Handler
    private var blockedAppsListener: ListenerRegistration? = null
    private var childConfigListener: ListenerRegistration? = null
    private var blockedPackages = HashSet<String>()
    private var currentChildId: String? = null
    private var currentUserId: String? = null
    private var lastBlockedApp: String? = null
    private var lastBlockTime: Long = 0
    private var currentForegroundApp: String? = null
    private var appStartTime: Long = 0

    // Almacenamiento temporal del tiempo usado
    private val timeUsedMap = HashMap<String, Int>()
    private val lastResetDateMap = HashMap<String, String>()
    private var lastActivePackage: String? = null

    // Tiempo total de uso del dispositivo
    private var totalUsageTime: Long = 0
    private var totalUsageStartTime: Long = 0
    private var dailyUsageLimit: Int = 0

    // Monitores
    private val fastMonitorRunnable = object : Runnable {
        override fun run() {
            val currentApp = getForegroundAppPackage()
            checkForegroundAppForBlocking()
            updateAppActiveState(currentApp)
            handler.postDelayed(this, 1500)
        }
    }

    private val timeMonitorRunnable = object : Runnable {
        override fun run() {
            checkTimeUsage()
            handler.postDelayed(this, 60000)
        }
    }

    private val totalUsageMonitorRunnable = object : Runnable {
        override fun run() {
            updateTotalUsageTime()
            handler.postDelayed(this, 60000)
        }
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("AppBlocker", "🟢 SERVICIO CREADO")

        initComponents()
        createNotificationChannel()
        startForegroundService()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "app_blocker_channel",
                "Control Parental",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundService() {
        try {
            val intent = Intent(this, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            val pendingIntent = PendingIntent.getActivity(
                this, 0, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val notification = NotificationCompat.Builder(this, "app_blocker_channel")
                .setContentTitle("🛡️ Control Parental")
                .setContentText("Monitoreando aplicaciones y tiempo de uso")
                .setSmallIcon(R.drawable.ic_menu_add_background)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setAutoCancel(false)
                .setShowWhen(false)
                .setSilent(true)
                .build()

            startForeground(123, notification)
            Log.d("AppBlocker", "✅ Servicio en primer plano iniciado")

        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error en foreground service", e)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("AppBlocker", "🚀 onStartCommand EJECUTADO")
        startBlockingMonitor()
        return START_STICKY
    }

    private fun initComponents() {
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        handler = Handler(Looper.getMainLooper())
        currentUserId = auth.currentUser?.uid
        totalUsageStartTime = System.currentTimeMillis()

        determineChildId()
    }

    private fun determineChildId() {
        val userId = currentUserId ?: return

        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val role = document.getString("role") ?: ""
                    Log.d("AppBlocker", "👤 Rol del usuario: $role")

                    when (role) {
                        "child" -> {
                            currentChildId = userId
                            Log.d("AppBlocker", "👶 Child ID determinado: $currentChildId")
                            setupFirebaseListeners()
                        }
                        "parent" -> {
                            findChildIdForParent(userId)
                        }
                        else -> {
                            Log.e("AppBlocker", "❌ Rol desconocido: $role")
                        }
                    }
                } else {
                    Log.e("AppBlocker", "❌ Documento de usuario no encontrado")
                }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error obteniendo rol del usuario", e)
            }
    }

    private fun findChildIdForParent(parentId: String) {
        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .whereEqualTo("status", "active")
            .get()
            .addOnSuccessListener { querySnapshot ->
                if (!querySnapshot.isEmpty) {
                    val document = querySnapshot.documents.first()
                    currentChildId = document.getString("childId")
                    Log.d("AppBlocker", "👨‍👦 Child ID encontrado para parent: $currentChildId")
                    setupFirebaseListeners()
                } else {
                    Log.e("AppBlocker", "❌ No se encontró guardianship activo para parent: $parentId")
                }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error buscando guardianship", e)
            }
    }

    private fun setupFirebaseListeners() {
        val childId = currentChildId ?: return

        Log.d("AppBlocker", "🔧 Configurando listeners para child: $childId")

        // Listener para apps bloqueadas
        blockedAppsListener = db.collection("children/$childId/apps")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("AppBlocker", "❌ Error en listener de apps", error)
                    return@addSnapshotListener
                }

                val newBlockedPackages = HashSet<String>()
                snapshot?.documents?.forEach { document ->
                    val packageName = document.id
                    val isBlocked = document.getBoolean("isBlocked") ?: false
                    val timeLimit = document.getLong("timeLimitMinutes") ?: 0
                    val timeUsed = document.getLong("timeUsedToday") ?: 0
                    val lastReset = document.getString("lastResetDate") ?: getCurrentDate()
                    val blockReason = document.getString("blockReason") ?: ""

                    if (isBlocked) {
                        newBlockedPackages.add(packageName)
                        Log.d("AppBlocker", "🔒 App bloqueada: $packageName - Razón: $blockReason")
                    }

                    if (timeLimit > 0) {
                        timeUsedMap[packageName] = timeUsed.toInt()
                        lastResetDateMap[packageName] = lastReset
                        Log.d("AppBlocker", "⏰ App con límite: $packageName - Usado: $timeUsed/$timeLimit")
                    } else if (timeUsed > 0) {
                        timeUsedMap[packageName] = timeUsed.toInt()
                        lastResetDateMap[packageName] = lastReset
                        Log.d("AppBlocker", "📊 App sin límite: $packageName - Tiempo usado: $timeUsed min")
                    }
                }

                blockedPackages = newBlockedPackages
                Log.d("AppBlocker", "📊 Lista actualizada: ${blockedPackages.size} apps bloqueadas")
            }

        // Listener para configuración general
        childConfigListener = db.collection("children").document(childId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("AppBlocker", "❌ Error en listener de configuración", error)
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    dailyUsageLimit = snapshot.getLong("dailyUsageLimit")?.toInt() ?: 0
                    val totalTimeUsed = snapshot.getLong("totalTimeUsedToday") ?: 0

                    totalUsageTime = totalTimeUsed
                    Log.d("AppBlocker", "📈 Configuración: Límite diario=$dailyUsageLimit min, Tiempo usado=$totalTimeUsed min")
                } else {
                    createChildConfigDocument(childId)
                }
            }
    }

    private fun createChildConfigDocument(childId: String) {
        val childData = hashMapOf<String, Any>(
            "dailyUsageLimit" to 0,
            "totalTimeUsedToday" to 0,
            "lastTotalUsageUpdate" to System.currentTimeMillis(),
            "createdAt" to FieldValue.serverTimestamp()
        )

        db.collection("children").document(childId)
            .set(childData)
            .addOnSuccessListener {
                Log.d("AppBlocker", "✅ Documento de configuración creado para child: $childId")
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error creando documento de configuración", e)
            }
    }

    private fun startBlockingMonitor() {
        handler.post(fastMonitorRunnable)
        handler.post(timeMonitorRunnable)
        handler.post(totalUsageMonitorRunnable)
        Log.d("AppBlocker", "🔍 Monitores iniciados")
    }

    // MONITOR RÁPIDO - Para bloqueo inmediato
    private fun checkForegroundAppForBlocking() {
        try {
            val currentApp = getForegroundAppPackage()

            if (currentApp != null &&
                currentApp != this.packageName &&
                currentApp != "android" &&
                blockedPackages.contains(currentApp)) {

                // Evitar bloqueos repetidos muy seguidos
                if (currentApp == lastBlockedApp && System.currentTimeMillis() - lastBlockTime < 3000) {
                    return
                }

                Log.d("AppBlocker", "🚫 BLOQUEANDO APP EN FOREGROUND: $currentApp")
                lastBlockedApp = currentApp
                lastBlockTime = System.currentTimeMillis()

                // USAR LA ACTIVIDAD EN LUGAR DEL OVERLAY DIRECTAMENTE
                showBlockActivity(currentApp)
            }
        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error en checkForegroundApp", e)
        }
    }

    // NUEVO MÉTODO: Usar AppBlockedActivity en lugar de overlay directo
    private fun showBlockActivity(packageName: String) {
        try {
            Log.d("AppBlocker", "🎬 Iniciando AppBlockedActivity para: $packageName")

            val intent = Intent(this, AppBlockedActivity::class.java).apply {
                putExtra("packageName", packageName)
                putExtra("appName", getAppName(packageName))
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)

            // ⚠️ ELIMINAR ESTA LÍNEA - NO LANZAR HOME SCREEN INMEDIATAMENTE
            // handler.postDelayed({ launchHomeScreen() }, 500)

        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error iniciando AppBlockedActivity", e)
        }
    }

    // MONITOR PARA LÍMITES POR APP
    private fun checkTimeUsage() {
        try {
            val previousApp = currentForegroundApp
            val newApp = getForegroundAppPackage()

            if (previousApp != null && previousApp != newApp) {
                processAppTime(previousApp)
            }

            currentForegroundApp = newApp

            if (newApp != null) {
                if (previousApp != newApp) {
                    appStartTime = System.currentTimeMillis()
                    Log.d("AppBlocker", "📱 App en foreground: $newApp")
                }
            }

        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error en checkTimeUsage", e)
        }
    }

    // ACTUALIZAR TIEMPO TOTAL DE USO
    private fun updateTotalUsageTime() {
        val childId = currentChildId ?: return

        val currentTime = System.currentTimeMillis()
        val timeElapsed = ((currentTime - totalUsageStartTime) / 60000).toInt()

        if (timeElapsed > 0) {
            totalUsageTime += timeElapsed
            totalUsageStartTime = currentTime

            if (dailyUsageLimit > 0 && totalUsageTime >= dailyUsageLimit) {
                Log.d("AppBlocker", "⏰ LÍMITE DIARIO ALCANZADO: $totalUsageTime/$dailyUsageLimit min")
                blockAllAppsForToday()
            }

            val updateData = hashMapOf<String, Any>(
                "totalTimeUsedToday" to totalUsageTime,
                "lastTotalUsageUpdate" to System.currentTimeMillis()
            )

            db.collection("children").document(childId)
                .set(updateData, SetOptions.merge())
                .addOnSuccessListener {
                    Log.d("AppBlocker", "📈 Tiempo total actualizado: $totalUsageTime min")
                }
                .addOnFailureListener { e ->
                    Log.e("AppBlocker", "❌ Error actualizando tiempo total", e)
                }
        }
    }

    private fun processAppTime(packageName: String) {
        try {
            val sessionTime = ((System.currentTimeMillis() - appStartTime) / 60000).toInt()
            if (sessionTime > 0) {
                updateTimeUsed(packageName, sessionTime)
                Log.d("AppBlocker", "⏱️ Tiempo usado en $packageName: $sessionTime min")
            }
        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error procesando tiempo", e)
        }
    }

    private fun updateTimeUsed(packageName: String, additionalTime: Int) {
        val childId = currentChildId ?: return

        checkAndResetDailyTime(packageName)

        val currentTimeUsed = timeUsedMap[packageName] ?: 0
        val newTimeUsed = currentTimeUsed + additionalTime
        timeUsedMap[packageName] = newTimeUsed

        Log.d("AppBlocker", "🔄 Actualizando tiempo: $packageName - Nuevo tiempo: $newTimeUsed")

        db.collection("children/$childId/apps").document(packageName)
            .update("timeUsedToday", newTimeUsed, "lastUsageUpdate", System.currentTimeMillis())
            .addOnSuccessListener {
                Log.d("AppBlocker", "✅ Tiempo actualizado en Firebase: $packageName - $newTimeUsed min")
                checkTimeLimit(packageName, newTimeUsed)
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error actualizando tiempo en Firebase", e)
            }
    }

    private fun checkAndResetDailyTime(packageName: String) {
        val currentDate = getCurrentDate()
        val lastResetDate = lastResetDateMap[packageName]

        if (lastResetDate != currentDate) {
            timeUsedMap[packageName] = 0
            lastResetDateMap[packageName] = currentDate

            val childId = currentChildId ?: return
            db.collection("children/$childId/apps").document(packageName)
                .update("timeUsedToday", 0, "lastResetDate", currentDate)
                .addOnSuccessListener {
                    Log.d("AppBlocker", "🔄 Tiempo reiniciado: $packageName")
                }
        }
    }

    private fun checkTimeLimit(packageName: String, timeUsed: Int) {
        val childId = currentChildId ?: return

        db.collection("children/$childId/apps").document(packageName)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val timeLimit = document.getLong("timeLimitMinutes") ?: 0
                    val isAlreadyBlocked = document.getBoolean("isBlocked") ?: false

                    Log.d("AppBlocker", "🔍 Verificando límite: $packageName - Usado: $timeUsed/$timeLimit - Bloqueada: $isAlreadyBlocked")

                    if (timeLimit > 0 && !isAlreadyBlocked) {
                        if (timeUsed >= timeLimit) {
                            Log.d("AppBlocker", "⏰ LÍMITE ALCANZADO - BLOQUEANDO: $packageName - $timeUsed/$timeLimit min")
                            blockAppPermanently(packageName, timeUsed, timeLimit.toInt())
                        } else {
                            val remaining = timeLimit - timeUsed
                            Log.d("AppBlocker", "✅ Tiempo disponible: $packageName - Quedan $remaining min")
                        }
                    } else if (timeLimit == 0L) {
                        Log.d("AppBlocker", "🔕 App sin límite de tiempo: $packageName")
                    } else if (isAlreadyBlocked) {
                        Log.d("AppBlocker", "🔒 App ya bloqueada: $packageName")
                    }
                }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error verificando límite de tiempo", e)
            }
    }

    private fun blockAppPermanently(packageName: String, timeUsed: Int, timeLimit: Int) {
        val childId = currentChildId ?: return

        val updateData = hashMapOf<String, Any>(
            "isBlocked" to true,
            "timeLimitMinutes" to 0,
            "blockReason" to "Tiempo agotado: $timeUsed/$timeLimit minutos",
            "blockedAt" to System.currentTimeMillis(),
            "timeUsedToday" to timeUsed,
            "lastUsageUpdate" to System.currentTimeMillis(),
            "updatedAt" to FieldValue.serverTimestamp()
        )

        Log.d("AppBlocker", "🔄 Bloqueando app: $packageName")

        db.collection("children/$childId/apps").document(packageName)
            .update(updateData)
            .addOnSuccessListener {
                Log.d("AppBlocker", "✅✅✅ APP BLOQUEADA: $packageName")
                blockedPackages.add(packageName)
                checkAndBlockIfForeground(packageName)
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocker", "❌ Error bloqueando app", e)
            }
    }

    private fun blockAllAppsForToday() {
        val childId = currentChildId ?: return

        Log.d("AppBlocker", "🚫 BLOQUEANDO TODAS LAS APPS - Límite diario alcanzado")
        // Mostrar actividad de bloqueo por tiempo total
        showTimeLimitActivity()
    }

    private fun showTimeLimitActivity() {
        try {
            Log.d("AppBlocker", "🎬 Iniciando AppBlockedActivity por límite de tiempo")

            val intent = Intent(this, AppBlockedActivity::class.java).apply {
                putExtra("packageName", "time_limit")
                putExtra("appName", "Todas las aplicaciones")
                putExtra("isTimeLimit", true)
                putExtra("totalUsageTime", totalUsageTime)
                putExtra("dailyUsageLimit", dailyUsageLimit)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(intent)

        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error iniciando actividad por límite de tiempo", e)
        }
    }
    private fun checkAndBlockIfForeground(packageName: String) {
        handler.post {
            val currentApp = getForegroundAppPackage()
            if (currentApp == packageName) {
                Log.d("AppBlocker", "🚫 App bloqueada en foreground: $packageName")
                showBlockActivity(packageName)
                // ⚠️ ELIMINAR ESTA LÍNEA TAMBIÉN
                // launchHomeScreen()
            }
        }
    }

    private fun getForegroundAppPackage(): String? {
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                val usageStatsManager = getSystemService(USAGE_STATS_SERVICE) as UsageStatsManager
                val time = System.currentTimeMillis()
                val stats = usageStatsManager.queryUsageStats(UsageStatsManager.INTERVAL_DAILY, time - 5000, time)
                stats?.maxByOrNull { it.lastTimeUsed }?.packageName
            } else null
        } catch (e: Exception) {
            null
        }
    }

    private fun launchHomeScreen() {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
        } catch (e: Exception) {
            Log.e("AppBlocker", "❌ Error lanzando HOME", e)
        }
    }

    private fun getAppName(packageName: String): String {
        return try {
            packageManager.getApplicationInfo(packageName, 0).loadLabel(packageManager).toString()
        } catch (e: Exception) {
            packageName
        }
    }

    private fun getCurrentDate(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date())
    }

    override fun onDestroy() {
        super.onDestroy()
        currentForegroundApp?.let { processAppTime(it) }
        updateTotalUsageTime()

        blockedAppsListener?.remove()
        childConfigListener?.remove()
        handler.removeCallbacks(fastMonitorRunnable)
        handler.removeCallbacks(timeMonitorRunnable)
        handler.removeCallbacks(totalUsageMonitorRunnable)
        Log.d("AppBlocker", "🛑 SERVICIO DESTRUIDO")
    }

    private fun updateAppActiveState(currentPackage: String?) {
        val childId = currentChildId ?: return

        if (currentPackage != null && currentPackage != lastActivePackage) {
            db.collection("children/$childId/apps").document(currentPackage)
                .update(
                    mapOf(
                        "isActive" to true,
                        "lastActive" to System.currentTimeMillis()
                    )
                )
                .addOnSuccessListener {
                    Log.d("AppBlocker", "✅ App activa: $currentPackage")
                }

            lastActivePackage?.let { previousPackage ->
                db.collection("children/$childId/apps").document(previousPackage)
                    .update("isActive", false)
                    .addOnSuccessListener {
                        Log.d("AppBlocker", "🔕 App inactiva: $previousPackage")
                    }
            }

            lastActivePackage = currentPackage
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null
}