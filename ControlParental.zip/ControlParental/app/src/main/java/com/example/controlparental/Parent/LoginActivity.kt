package com.example.controlparental.Parent

import android.app.Dialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.util.Patterns
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.util.HashMap

class LoginActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var btnLogin: MaterialButton
    private lateinit var btnGoogle: MaterialCardView
    private lateinit var tvRegister: TextView
    private lateinit var tvForgotPassword: TextView

    private val webClientId = "26030669913-b5uskbqqngr80l9jgtt1a24ggr5901k2.apps.googleusercontent.com"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Verificar si ya está autenticado
        checkCurrentUser()

        // Vincular vistas
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        btnLogin = findViewById(R.id.btnLogin)
        btnGoogle = findViewById(R.id.btnGoogle)
        tvRegister = findViewById(R.id.tvRegister)
        tvForgotPassword = findViewById(R.id.tvForgotPassword)

        // Configurar acciones
        btnLogin.setOnClickListener { loginWithEmail() }
        btnGoogle.setOnClickListener { signInWithGoogle() }
        tvRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        tvForgotPassword.setOnClickListener {
            showForgotPasswordDialog()
        }
    }

    private fun showForgotPasswordDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_forgot_password, null)
        val etResetEmail = dialogView.findViewById<TextInputEditText>(R.id.etResetEmail)
        val btnCancel = dialogView.findViewById<MaterialButton>(R.id.btnCancel)
        val btnSendReset = dialogView.findViewById<MaterialButton>(R.id.btnSendReset)

        // Prellenar con el email del campo de login si existe
        etEmail.text?.toString()?.let { email ->
            if (email.isNotEmpty()) {
                etResetEmail.setText(email)
            }
        }

        val dialog = MaterialAlertDialogBuilder(this)
            .setView(dialogView)
            .setCancelable(true)
            .create()

        btnCancel.setOnClickListener {
            dialog.dismiss()
        }

        btnSendReset.setOnClickListener {
            val email = etResetEmail.text.toString().trim()
            if (validateResetEmail(email)) {
                sendPasswordResetEmail(email, dialog)
            }
        }

        dialog.show()
    }

    private fun validateResetEmail(email: String): Boolean {
        if (email.isEmpty()) {
            showErrorDialog("Ingresa tu correo electrónico")
            return false
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            showErrorDialog("Correo electrónico inválido")
            return false
        }
        return true
    }

    private fun sendPasswordResetEmail(email: String, dialog: Dialog) {
        val btnSendReset = dialog.findViewById<MaterialButton>(R.id.btnSendReset)

        // Mostrar estado de carga
        btnSendReset.isEnabled = false
        btnSendReset.text = "Enviando..."

        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    dialog.dismiss()
                    showSuccessDialog("¡Enlace enviado! 📧\nRevisa tu correo electrónico para restablecer tu contraseña.")
                } else {
                    btnSendReset.isEnabled = true
                    btnSendReset.text = "Enviar"

                    val errorMessage = when {
                        task.exception?.message?.contains("user-not-found", ignoreCase = true) == true ->
                            "No existe una cuenta con este correo electrónico"
                        task.exception?.message?.contains("network", ignoreCase = true) == true ->
                            "Error de conexión. Verifica tu internet"
                        task.exception?.message?.contains("invalid-email", ignoreCase = true) == true ->
                            "Correo electrónico inválido"
                        else -> "Error al enviar el enlace: ${task.exception?.message}"
                    }
                    showErrorDialog(errorMessage)
                }
            }
    }

    private fun showSuccessDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("¡Éxito!")
            .setMessage(message)
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(android.R.drawable.star_big_on)
            .show()
    }

    private fun showErrorDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(android.R.drawable.ic_menu_close_clear_cancel)
            .show()
    }

    private fun checkCurrentUser() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            // Usuario ya está logueado, verificar si es padre
            verifyUserRoleAndRedirect(currentUser.uid)
        }
    }

    private fun loginWithEmail() {
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()

        if (!validateForm(email, password)) {
            return
        }

        setLoadingState(true)

        auth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                setLoadingState(false)

                if (task.isSuccessful) {
                    handleSuccessfulLogin()
                } else {
                    val errorMessage = when {
                        task.exception?.message?.contains("password", ignoreCase = true) == true ->
                            "Contraseña incorrecta"
                        task.exception?.message?.contains("email", ignoreCase = true) == true ->
                            "Correo electrónico no encontrado"
                        task.exception?.message?.contains("network", ignoreCase = true) == true ->
                            "Error de conexión. Verifica tu internet"
                        task.exception?.message?.contains("invalid-credential", ignoreCase = true) == true ->
                            "Credenciales incorrectas. Verifica tu email y contraseña"
                        task.exception?.message?.contains("too-many-requests", ignoreCase = true) == true ->
                            "Demasiados intentos fallidos. Intenta más tarde o restablece tu contraseña"
                        task.exception?.message?.contains("user-disabled", ignoreCase = true) == true ->
                            "Esta cuenta ha sido deshabilitada"
                        else -> "Error al iniciar sesión: ${task.exception?.message}"
                    }
                    showError(errorMessage)
                }
            }
    }

    private fun validateForm(email: String, password: String): Boolean {
        // Resetear errores
        etEmail.error = null
        etPassword.error = null

        var isValid = true

        if (email.isEmpty()) {
            etEmail.error = "Ingresa tu correo electrónico"
            etEmail.requestFocus()
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Correo electrónico inválido"
            etEmail.requestFocus()
            isValid = false
        }

        if (password.isEmpty()) {
            etPassword.error = "Ingresa tu contraseña"
            if (isValid) etPassword.requestFocus()
            isValid = false
        } else if (password.length < 6) {
            etPassword.error = "La contraseña debe tener al menos 6 caracteres"
            if (isValid) etPassword.requestFocus()
            isValid = false
        }

        return isValid
    }

    private fun signInWithGoogle() {
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(webClientId)
            .requestEmail()
            .build()

        val googleSignInClient = GoogleSignIn.getClient(this, gso)
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                val account = task.getResult(ApiException::class.java)!!
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                setLoadingState(false)
                showError("Error en inicio con Google: ${e.message}")
                Log.e("LoginActivity", "Google sign-in failed", e)
            }
        }
    }

    private fun firebaseAuthWithGoogle(idToken: String) {
        setLoadingState(true)

        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    handleSuccessfulLogin()
                } else {
                    setLoadingState(false)
                    showError("Error al autenticar con Google: ${task.exception?.message}")
                    Log.e("LoginActivity", "Google authentication failed", task.exception)
                }
            }
    }

    private fun handleSuccessfulLogin() {
        val user = auth.currentUser
        if (user != null) {
            // Verificar si el usuario existe en Firestore
            db.collection("users").document(user.uid)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        // Usuario existe, verificar rol y redirigir
                        verifyUserRoleAndRedirect(user.uid)
                    } else {
                        // Usuario nuevo con Google, crear perfil
                        createUserProfileForGoogle(user)
                    }
                }
                .addOnFailureListener { e ->
                    setLoadingState(false)
                    showError("Error al verificar perfil: ${e.message}")
                    Log.e("LoginActivity", "Error checking user profile", e)
                }
        } else {
            setLoadingState(false)
            showError("Error: usuario no autenticado")
        }
    }

    private fun createUserProfileForGoogle(user: com.google.firebase.auth.FirebaseUser) {
        // Solución al problema del tipo: usar HashMap explícitamente
        val userData = HashMap<String, Any>()
        userData["name"] = user.displayName ?: "Usuario Google"
        userData["email"] = user.email ?: ""
        userData["uid"] = user.uid
        userData["role"] = "parent"
        userData["createdAt"] = FieldValue.serverTimestamp()
        userData["updatedAt"] = FieldValue.serverTimestamp()
        userData["profileComplete"] = true
        userData["isGoogleAccount"] = true

        db.collection("users").document(user.uid)
            .set(userData)
            .addOnSuccessListener {
                Log.d("LoginActivity", "Perfil de Google creado exitosamente")
                redirectToParentHome(user.uid)
            }
            .addOnFailureListener { e ->
                setLoadingState(false)
                showError("Error al crear perfil: ${e.message}")
                Log.e("LoginActivity", "Error creating Google user profile", e)
            }
    }

    private fun verifyUserRoleAndRedirect(userId: String) {
        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val role = document.getString("role")
                    if (role == "parent") {
                        redirectToParentHome(userId)
                    } else {
                        // Si no es padre, mostrar error y cerrar sesión
                        auth.signOut()
                        setLoadingState(false)
                        showError("Esta aplicación es solo para padres. Los niños deben usar la aplicación correspondiente.")
                    }
                } else {
                    // Documento no existe, crear uno
                    createUserProfileForGoogle(auth.currentUser!!)
                }
            }
            .addOnFailureListener { e ->
                setLoadingState(false)
                showError("Error al cargar perfil: ${e.message}")
                Log.e("LoginActivity", "Error verifying user role", e)
            }
    }

    private fun redirectToParentHome(parentId: String) {
        // Guardar el ID del padre y datos de usuario en SessionManager
        val currentUser = auth.currentUser
        currentUser?.let { user ->
            db.collection("users").document(user.uid)
                .get()
                .addOnSuccessListener { document ->
                    val userName = if (document.exists()) {
                        document.getString("name") ?: user.displayName ?: "Usuario"
                    } else {
                        user.displayName ?: "Usuario"
                    }

                    // Guardar todos los datos en SessionManager usando la nueva función
                    SessionManager.saveUserData(
                        this,
                        parentId = parentId,
                        email = user.email ?: "",
                        name = userName,
                        role = "parent"
                    )

                    // Registrar dispositivo
                    registerParentDevice(parentId)

                    showSuccess("¡Bienvenido de vuelta! 👋")

                    val intent = Intent(this, ParentHomeActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    finish()
                }
        }
    }

    private fun registerParentDevice(parentId: String) {
        val manufacturer = android.os.Build.MANUFACTURER.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase() else it.toString()
        }
        val model = android.os.Build.MODEL
        val deviceName = "$manufacturer $model"

        val androidId = android.provider.Settings.Secure.getString(
            contentResolver,
            android.provider.Settings.Secure.ANDROID_ID
        )

        val deviceData = HashMap<String, Any>()
        deviceData["deviceName"] = deviceName
        deviceData["androidId"] = androidId
        deviceData["linkedAt"] = FieldValue.serverTimestamp()
        deviceData["isActive"] = true
        deviceData["lastSeen"] = FieldValue.serverTimestamp()
        deviceData["deviceType"] = "parent"

        db.collection("parents/$parentId/devices").document(androidId)
            .set(deviceData)
            .addOnSuccessListener {
                Log.d("LoginActivity", "✅ Dispositivo del padre registrado")
            }
            .addOnFailureListener { e ->
                Log.e("LoginActivity", "❌ Error al registrar dispositivo: ${e.message}")
            }
    }

    private fun setLoadingState(isLoading: Boolean) {
        btnLogin.isEnabled = !isLoading
        btnLogin.text = if (isLoading) "Iniciando sesión..." else "Iniciar Sesión"
        btnGoogle.isEnabled = !isLoading
    }

    private fun showSuccess(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    companion object {
        private const val RC_SIGN_IN = 9001
    }
}