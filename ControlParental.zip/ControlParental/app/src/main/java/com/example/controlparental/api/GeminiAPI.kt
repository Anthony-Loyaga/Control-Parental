package com.example.controlparental.ai

import android.content.Context
import android.util.Log
import com.google.ai.client.generativeai.GenerativeModel
import com.google.ai.client.generativeai.type.content
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object GeminiAPI {
    private const val TAG = "GeminiAPI"
    private var model: GenerativeModel? = null

    /**
     * Inicializa el cliente de Gemini (leer API KEY desde AndroidManifest meta-data).
     * Llama a esto una sola vez (ej: onCreate de tu Fragment/Activity).
     */
    fun initialize(context: Context) {
        try {
            val appInfo = context.packageManager
                .getApplicationInfo(context.packageName, android.content.pm.PackageManager.GET_META_DATA)
            val apiKey = appInfo.metaData.getString("GEMINI_API_KEY")

            if (apiKey.isNullOrEmpty()) {
                Log.e(TAG, "GEMINI_API_KEY no encontrada en AndroidManifest meta-data")
                return
            }

            // ******** USAR SIEMPRE gemini-2.5-flash ********
            model = GenerativeModel(
                modelName = "gemini-2.5-flash",
                apiKey = apiKey
            )

            Log.d(TAG, "Gemini inicializado con gemini-2.5-flash")
        } catch (e: Exception) {
            Log.e(TAG, "Error inicializando Gemini: ${e.message}", e)
        }
    }

    /**
     * Llama al modelo y devuelve el texto crudo que retorna Gemini.
     * Uso: en coroutine (lifecycleScope.launch { val r = GeminiAPI.generate(prompt) })
     */
    suspend fun generate(prompt: String): String = withContext(Dispatchers.IO) {
        try {
            val m = model ?: run {
                val msg = "Model no inicializado. Llama a GeminiAPI.initialize(context) primero."
                Log.e(TAG, msg)
                return@withContext msg
            }

            Log.d(TAG, "Prompt enviado a Gemini:\n$prompt")

            val response = m.generateContent(
                content { text(prompt) }
            )

            val raw = response.text ?: ""
            Log.d(TAG, "Respuesta RAW de Gemini:\n$raw")
            raw
        } catch (e: Exception) {
            Log.e(TAG, "ERROR en Gemini.generate: ${e.message}", e)
            "ERROR_GEMINI: ${e.message}"
        }
    }
}
