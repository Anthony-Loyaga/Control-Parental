package com.example.controlparental.Parent

import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.example.controlparental.Parent.Fragment.AppsFragment
import com.example.controlparental.Parent.Fragment.DashboardFragment
import com.example.controlparental.Parent.Fragment.HomeFragment
import com.example.controlparental.R
import com.example.controlparental.Parent.Fragment.UbicacionFragment
import com.example.controlparental.Parent.Fragments.ChatBotFragment
import com.example.controlparental.parent.services.ParentNotificationService
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ParentHomeActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private var parentId: String = ""
    private var parentName: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_parent_home)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        loadParentData()
        val bottomNav: BottomNavigationView = findViewById(R.id.bottomNavigation)
        bottomNav.setOnItemSelectedListener { item ->
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment.Companion.newInstance(parentId, parentName)
                R.id.nav_location -> UbicacionFragment()
                R.id.nav_apps -> AppsFragment()
                R.id.nav_reports -> ChatBotFragment()
                R.id.nav_settings -> ParentProfileFragment()
                else -> HomeFragment.Companion.newInstance(parentId, parentName)
            }
            supportFragmentManager.beginTransaction().replace(R.id.fragmentContainer, fragment).commit()
            true
        }

        if (supportFragmentManager.findFragmentById(R.id.fragmentContainer) == null) {
            supportFragmentManager.beginTransaction()
                .replace(R.id.fragmentContainer, HomeFragment.Companion.newInstance(parentId, parentName))
                .commit()
        }
        startNotificationService()
    }
    private fun startNotificationService() {
        try {
            val intent = Intent(this, ParentNotificationService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Log.d("ParentHome", "✅ Servicio de notificaciones iniciado")
        } catch (e: Exception) {
            Log.e("ParentHome", "❌ Error iniciando servicio: ${e.message}")
        }
    }
    private fun loadParentData() {
        val userId = auth.currentUser?.uid ?: return
        db.collection("users").document(userId)
            .get()
            .addOnSuccessListener { doc ->
                if (doc.exists()) {
                    parentId = doc.id
                    parentName = doc.getString("name") ?: "Apoderado"
                } else {
                    Toast.makeText(this, "Perfil no encontrado", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar datos: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}