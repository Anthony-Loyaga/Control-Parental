package com.example.controlparental.Parent

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class UnlockRequestActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    private lateinit var childName: String
    private lateinit var appName: String
    private lateinit var packageName: String

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_unlock_request)

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        // Obtener datos del intent
        childName = intent.getStringExtra("childName") ?: "Tu hijo"
        appName = intent.getStringExtra("appName") ?: "una aplicación"
        packageName = intent.getStringExtra("packageName") ?: ""

        initViews()
        setupClickListeners()
    }

    private fun initViews() {
        findViewById<TextView>(R.id.tvRequestTitle).text = "Solicitud de Desbloqueo"
        findViewById<TextView>(R.id.tvRequestMessage).text =
            "$childName quiere usar $appName"

        findViewById<TextView>(R.id.tvAppInfo).text = "Aplicación: $appName"
    }

    private fun setupClickListeners() {
        findViewById<Button>(R.id.btnApprove).setOnClickListener {
            approveUnlockRequest()
        }

        findViewById<Button>(R.id.btnDeny).setOnClickListener {
            denyUnlockRequest()
        }
    }

    private fun approveUnlockRequest() {
        val parentId = auth.currentUser?.uid ?: return

        // Crear un desbloqueo temporal (por ejemplo, 1 hora)
        val unlockData = hashMapOf(
            "packageName" to packageName,
            "appName" to appName,
            "childName" to childName,
            "parentId" to parentId,
            "approvedAt" to System.currentTimeMillis(),
            "expiresAt" to System.currentTimeMillis() + (60 * 60 * 1000), // 1 hora
            "status" to "approved"
        )

        db.collection("temporary_unlocks")
            .add(unlockData)
            .addOnSuccessListener {
                Toast.makeText(this, "App desbloqueada temporalmente", Toast.LENGTH_SHORT).show()

                // Enviar notificación al niño
                sendUnlockResponseToChild("approved")

                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun denyUnlockRequest() {
        // Enviar notificación de rechazo al niño
        sendUnlockResponseToChild("denied")
        Toast.makeText(this, "Solicitud rechazada", Toast.LENGTH_SHORT).show()
        finish()
    }

    private fun sendUnlockResponseToChild(response: String) {
        val parentId = auth.currentUser?.uid ?: return

        // Buscar el niño vinculado a este padre
        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .get()
            .addOnSuccessListener { documents ->
                for (document in documents) {
                    val childId = document.getString("childId")
                    if (childId != null) {
                        // Aquí enviarías una notificación FCM al niño
                        // Por ahora solo un log
                        Log.d("UnlockRequest", "Respuesta $response enviada a $childId")
                    }
                }
            }
    }
}