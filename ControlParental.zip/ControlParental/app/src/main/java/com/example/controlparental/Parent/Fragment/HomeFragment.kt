package com.example.controlparental.Parent.Fragment

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.example.controlparental.Parent.LinkDeviceActivity
import com.example.controlparental.R
import com.google.android.material.card.MaterialCardView
import com.google.firebase.firestore.FirebaseFirestore

class HomeFragment : Fragment() {

    private var parentId: String = ""
    private var parentName: String = ""

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_home, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Recibir argumentos
        arguments?.let {
            parentId = it.getString("parentId") ?: ""
            parentName = it.getString("parentName") ?: "Apoderado"
        }

        // Mostrar nombre (opcional)
        view.findViewById<TextView>(R.id.tvDeviceCount).text = "Bienvenido, $parentName"

        // Configurar botón de vinculación
        val cardLinkDevice = view.findViewById<MaterialCardView>(R.id.cardLinkDevice)
        loadLinkedDevices(parentId)
        cardLinkDevice.setOnClickListener {
            startActivity(Intent(requireContext(), LinkDeviceActivity::class.java))
            generateLinkingQR(parentId)
        }
    }

    private fun generateLinkingQR(parentId: String) {

    }
    private fun loadLinkedDevices(parentId: String) {
        val deviceContainer = view?.findViewById<LinearLayout>(R.id.deviceListContainer) ?: return

        // Buscar qué hijos pertenecen a este padre
        FirebaseFirestore.getInstance().collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .whereEqualTo("status", "active")
            .get()
            .addOnSuccessListener { snapshot ->

                deviceContainer.removeAllViews()

                for (doc in snapshot) {
                    val childId = doc.getString("childId") ?: continue

                    FirebaseFirestore.getInstance()
                        .collection("children/$childId/devices")
                        .get()
                        .addOnSuccessListener { deviceSnap ->

                            for (deviceDoc in deviceSnap) {
                                val deviceName = deviceDoc.getString("deviceName") ?: "Desconocido"

                                val view = layoutInflater.inflate(
                                    R.layout.item_device,
                                    deviceContainer,
                                    false
                                )

                                view.findViewById<TextView>(R.id.tvDeviceName).text = deviceName
                                deviceContainer.addView(view)
                            }

                        }
                }
            }
    }

    companion object {
        fun newInstance(parentId: String, parentName: String): HomeFragment {
            val fragment = HomeFragment()
            val args = Bundle().apply {
                putString("parentId", parentId)
                putString("parentName", parentName)
            }
            fragment.arguments = args
            return fragment
        }
    }
}