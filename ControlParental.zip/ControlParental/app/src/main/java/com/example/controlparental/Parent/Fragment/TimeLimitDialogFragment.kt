package com.example.controlparental.Parent.Fragment
import androidx.fragment.app.activityViewModels
import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import android.widget.EditText
import androidx.fragment.app.DialogFragment
import com.example.controlparental.Parent.Fragment.AppsFragment
import com.example.controlparental.R
import com.example.controlparental.Parent.ViewModel.ParentalActionsViewModel
class TimeLimitDialogFragment : DialogFragment() {
    private val vm: ParentalActionsViewModel by activityViewModels()
    companion object {
        fun newInstance(packageName: String, currentLimit: Int): TimeLimitDialogFragment {
            return TimeLimitDialogFragment().apply {
                arguments = Bundle().apply {
                    putString("packageName", packageName)
                    putInt("currentLimit", currentLimit)
                }
            }
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val packageName = requireArguments().getString("packageName")!!
        val currentLimit = requireArguments().getInt("currentLimit")

        val view = requireActivity().layoutInflater.inflate(R.layout.dialog_time_limit, null)
        val etMinutes = view.findViewById<EditText>(R.id.etMinutes)
        etMinutes.setText(if (currentLimit > 0) currentLimit.toString() else "")

        return AlertDialog.Builder(requireContext())
            .setTitle("Límite para: $packageName")
            .setView(view)
            .setPositiveButton("Guardar") { _, _ ->
                val minutes = etMinutes.text.toString().toIntOrNull() ?: 0
                vm.setAppLimit(packageName, minutes)
            }
            .setNegativeButton("Cancelar", null)
            .create()
    }
}