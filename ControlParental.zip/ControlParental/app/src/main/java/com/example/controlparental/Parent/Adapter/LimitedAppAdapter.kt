package com.example.controlparental.Parent.Adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ProgressBar
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.R

class LimitedAppAdapter(private val apps: List<LimitedApp>) : RecyclerView.Adapter<LimitedAppAdapter.ViewHolder>() {

    data class LimitedApp(val name: String, val usedMinutes: Int, val limitMinutes: Int)

    class ViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val appName: TextView = view.findViewById(R.id.tvAppName)
        val progressBar: ProgressBar = view.findViewById(R.id.progressBar)
        val timeRemaining: TextView = view.findViewById(R.id.tvTimeRemaining)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_limited_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val app = apps[position]
        holder.appName.text = app.name
        holder.timeRemaining.text = "${app.limitMinutes - app.usedMinutes} min restantes"

        val progress = if (app.limitMinutes > 0) {
            (app.usedMinutes * 100 / app.limitMinutes).coerceAtMost(100)
        } else 0
        holder.progressBar.progress = progress
    }

    override fun getItemCount() = apps.size
}