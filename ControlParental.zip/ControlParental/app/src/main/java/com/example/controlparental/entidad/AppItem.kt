package com.example.controlparental.entidad

data class AppItem(
    val packageName: String,
    val name: String,
    val category: String,
    val todayUsageMinutes: Int,
    val isBlocked: Boolean,
    val timeLimitMinutes: Int = 0,
    val isActive: Boolean = false,
    val lastActive: Long = 0L,
    val timeUsedToday: Int = 0,
    val lastUsageUpdate: Long = 0L,
    val iconUrl: String? = null
)