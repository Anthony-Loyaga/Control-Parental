package com.example.controlparental.children

import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AppBlockedActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private val handler = Handler(Looper.getMainLooper())

    private var overlayView: View? = null
    private var windowManager: WindowManager? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.d("AppBlocked", "🎬 onCreate iniciado")

        // Inicializar componentes
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val packageName = intent.getStringExtra("packageName") ?: ""
        val appName = intent.getStringExtra("appName") ?: "App"
        val isTimeLimit = intent.getBooleanExtra("isTimeLimit", false)

        Log.d("AppBlocked", "🔒 Bloqueando: $appName ($packageName), isTimeLimit: $isTimeLimit")

        if (isTimeLimit) {
            // Mostrar overlay de límite de tiempo
            val totalUsageTime = intent.getLongExtra("totalUsageTime", 0)
            val dailyUsageLimit = intent.getIntExtra("dailyUsageLimit", 0)
            showTimeLimitOverlay(totalUsageTime, dailyUsageLimit)
        } else {
            // Mostrar overlay normal de app bloqueada
            showBlockOverlay(packageName, appName)
        }

        setupBackPressedHandler()
    }
    private fun showTimeLimitOverlay(totalUsageTime: Long, dailyUsageLimit: Int) {
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            overlayView = inflater.inflate(R.layout.overlay_blocked_app, null)

            // Configurar UI para límite de tiempo
            overlayView?.findViewById<TextView>(R.id.tvBlockedAppName)?.text =
                "Tiempo diario agotado"

            // Puedes agregar un TextView adicional para mostrar el motivo
            val message = "Has usado el dispositivo por $totalUsageTime minutos.\nLímite diario: $dailyUsageLimit minutos."

            // Botón Volver a Inicio
            overlayView?.findViewById<Button>(R.id.btnReturnHome)?.apply {
                setOnClickListener {
                    Log.d("AppBlocked", "🎯 CLICK RECIBIDO: btnReturnHome (tiempo)")
                    removeOverlay()
                    returnToHome()
                }
                isFocusable = true
                isClickable = true
                isEnabled = true
            }

            // Botón Solicitar Desbloqueo - OCULTAR o MOSTRAR MENSAJE DIFERENTE
            overlayView?.findViewById<Button>(R.id.btnRequestUnlock)?.apply {
                text = "Solicitar más tiempo"
                setOnClickListener {
                    Log.d("AppBlocked", "🎯 CLICK RECIBIDO: Solicitar más tiempo")
                    requestTimeExtension(dailyUsageLimit)
                }
                isFocusable = true
                isClickable = true
                isEnabled = true
            }

            setupWindowManager()
            Log.d("AppBlocked", "✅ Overlay de tiempo configurado correctamente")

        } catch (e: Exception) {
            Log.e("AppBlocked", "❌ Error en showTimeLimitOverlay: ${e.message}")
            finish()
        }
    }
    // NUEVO MÉTODO PARA SOLICITAR EXTENSIÓN DE TIEMPO
    private fun requestTimeExtension(currentLimit: Int) {
        Log.d("AppBlocked", "🔄 Iniciando solicitud de extensión de tiempo")

        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.e("AppBlocked", "❌ No hay usuario logueado")
            Toast.makeText(this, "Error: No hay usuario logueado", Toast.LENGTH_SHORT).show()
            return
        }

        db.collection("users").document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val childName = document.getString("name") ?: "Tu hijo"
                    val parentId = document.getString("parentId")

                    Log.d("AppBlocked", "📄 Child: $childName, Parent: $parentId")

                    if (!parentId.isNullOrEmpty()) {
                        sendTimeExtensionRequest(parentId, childName, currentLimit)
                    } else {
                        Log.e("AppBlocked", "❌ ParentId no encontrado")
                        Toast.makeText(this, "Error: No se encontró padre vinculado", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("AppBlocked", "❌ Documento de usuario no existe")
                    Toast.makeText(this, "Error: Datos de usuario no encontrados", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocked", "❌ Error obteniendo usuario: ${e.message}")
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
    private fun sendTimeExtensionRequest(parentId: String, childName: String, currentLimit: Int) {
        val currentUser = auth.currentUser ?: return

        val requestData = hashMapOf(
            "childId" to currentUser.uid,
            "childName" to childName,
            "parentId" to parentId,
            "currentLimit" to currentLimit,
            "requestedAt" to System.currentTimeMillis(),
            "status" to "pending",
            "type" to "time_extension"
        )

        Log.d("AppBlocked", "📤 Enviando solicitud de tiempo a Firestore...")

        db.collection("time_extension_requests")
            .add(requestData)
            .addOnSuccessListener { requestDoc ->
                Log.d("AppBlocked", "✅ Solicitud de tiempo creada: ${requestDoc.id}")

                val notificationData = hashMapOf(
                    "title" to "Solicitud de más tiempo",
                    "message" to "$childName quiere más tiempo de uso del dispositivo",
                    "childId" to currentUser.uid,
                    "childName" to childName,
                    "currentLimit" to currentLimit,
                    "requestId" to requestDoc.id,
                    "timestamp" to System.currentTimeMillis(),
                    "viewed" to false,
                    "type" to "time_extension"
                )

                db.collection("parents")
                    .document(parentId)
                    .collection("notificaciones")
                    .add(notificationData)
                    .addOnSuccessListener {
                        Log.d("AppBlocked", "✅ Notificación de tiempo enviada al padre")
                        Toast.makeText(this, "✅ Solicitud de más tiempo enviada", Toast.LENGTH_LONG).show()
                    }
                    .addOnFailureListener { e ->
                        Log.e("AppBlocked", "❌ Error en notificación de tiempo: ${e.message}")
                        Toast.makeText(this, "Solicitud enviada, pero error en notificación", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocked", "❌ Error en solicitud de tiempo: ${e.message}")
                Toast.makeText(this, "Error al enviar solicitud: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }
    private fun showBlockOverlay(packageName: String, appName: String) {
        try {
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            val inflater = LayoutInflater.from(this)
            overlayView = inflater.inflate(R.layout.overlay_blocked_app, null)

            setupUI(packageName, appName)
            setupWindowManager()

            Log.d("AppBlocked", "✅ Overlay configurado correctamente")
        } catch (e: Exception) {
            Log.e("AppBlocked", "❌ Error en showBlockOverlay: ${e.message}")
            finish()
        }
    }

    private fun setupUI(packageName: String, appName: String) {
        // Configurar texto
        overlayView?.findViewById<TextView>(R.id.tvBlockedAppName)?.text = "$appName está bloqueada"

        // Botón Volver a Inicio - CON MÁS LOGS
        overlayView?.findViewById<Button>(R.id.btnReturnHome)?.apply {
            setOnClickListener {
                Log.d("AppBlocked", "🎯 CLICK RECIBIDO: btnReturnHome")
                removeOverlay()
                returnToHome()
            }

            // Forzar focus y clickable
            isFocusable = true
            isClickable = true
            isEnabled = true
        }

        // Botón Solicitar Desbloqueo - CON MÁS LOGS
        overlayView?.findViewById<Button>(R.id.btnRequestUnlock)?.apply {
            setOnClickListener {
                Log.d("AppBlocked", "🎯 CLICK RECIBIDO: btnRequestUnlock")
                requestUnlock(packageName, appName)
            }

            // Forzar focus y clickable
            isFocusable = true
            isClickable = true
            isEnabled = true
            requestFocus()
        }

        // Hacer que toda la vista sea clickable
        overlayView?.isClickable = true
        overlayView?.isFocusable = true
        overlayView?.isFocusableInTouchMode = true
    }

    private fun setupWindowManager() {
        val params = WindowManager.LayoutParams().apply {
            // Configuración básica
            width = WindowManager.LayoutParams.MATCH_PARENT
            height = WindowManager.LayoutParams.MATCH_PARENT

            // Tipo de ventana según versión Android
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // BANDERAS CRÍTICAS - Permitir interacción completa
            flags = (WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                    WindowManager.LayoutParams.FLAG_WATCH_OUTSIDE_TOUCH or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS)

            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.START
            x = 0
            y = 0
        }

        try {
            windowManager?.addView(overlayView, params)
            Log.d("AppBlocked", "🪟 Vista agregada al WindowManager")
        } catch (e: Exception) {
            Log.e("AppBlocked", "❌ Error agregando vista: ${e.message}")
            // Fallback: usar Activity normal
            setContentView(R.layout.overlay_blocked_app)
            setupFallbackUI()
        }
    }

    private fun setupFallbackUI() {
        Log.d("AppBlocked", "🔄 Usando fallback UI normal")

        val packageName = intent.getStringExtra("packageName") ?: ""
        val appName = intent.getStringExtra("appName") ?: "App"

        findViewById<TextView>(R.id.tvBlockedAppName)?.text = "$appName está bloqueada"

        findViewById<Button>(R.id.btnReturnHome)?.setOnClickListener {
            Log.d("AppBlocked", "🎯 CLICK FALLBACK: btnReturnHome")
            returnToHome()
        }

        findViewById<Button>(R.id.btnRequestUnlock)?.setOnClickListener {
            Log.d("AppBlocked", "🎯 CLICK FALLBACK: btnRequestUnlock")
            requestUnlock(packageName, appName)
        }
    }

    private fun requestUnlock(packageName: String, appName: String) {
        Log.d("AppBlocked", "🔄 Iniciando requestUnlock...")

        val currentUser = auth.currentUser
        if (currentUser == null) {
            Log.e("AppBlocked", "❌ Usuario no autenticado")
            Toast.makeText(this, "Error: No hay usuario logueado", Toast.LENGTH_SHORT).show()
            return
        }

        Log.d("AppBlocked", "👤 Usuario: ${currentUser.uid}")

        // Obtener datos del usuario
        db.collection("users").document(currentUser.uid)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    val childName = document.getString("name") ?: "Tu hijo"
                    val parentId = document.getString("parentId")

                    Log.d("AppBlocked", "📄 Child: $childName, Parent: $parentId")

                    if (!parentId.isNullOrEmpty()) {
                        sendUnlockRequest(parentId, childName, packageName, appName)
                    } else {
                        Log.e("AppBlocked", "❌ ParentId no encontrado")
                        Toast.makeText(this, "Error: No se encontró padre vinculado", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Log.e("AppBlocked", "❌ Documento de usuario no existe")
                    Toast.makeText(this, "Error: Datos de usuario no encontrados", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocked", "❌ Error obteniendo usuario: ${e.message}")
                Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun sendUnlockRequest(parentId: String, childName: String, packageName: String, appName: String) {
        val currentUser = auth.currentUser ?: return

        val requestData = hashMapOf(
            "childId" to currentUser.uid,
            "childName" to childName,
            "parentId" to parentId,
            "packageName" to packageName,
            "appName" to appName,
            "requestedAt" to System.currentTimeMillis(),
            "status" to "pending",
            "type" to "unlock_request"
        )

        Log.d("AppBlocked", "📤 Enviando solicitud a Firestore...")

        // 1. Crear solicitud en unlock_requests
        db.collection("unlock_requests")
            .add(requestData)
            .addOnSuccessListener { requestDoc ->
                Log.d("AppBlocked", "✅ Solicitud creada: ${requestDoc.id}")

                // 2. Crear notificación para el padre
                val notificationData = hashMapOf(
                    "title" to "Solicitud de desbloqueo",
                    "message" to "$childName quiere usar $appName",
                    "childId" to currentUser.uid,
                    "childName" to childName,
                    "appName" to appName,
                    "packageName" to packageName,
                    "requestId" to requestDoc.id,
                    "timestamp" to System.currentTimeMillis(),
                    "viewed" to false,
                    "type" to "unlock_request"
                )

                db.collection("parents")
                    .document(parentId)
                    .collection("notificaciones")
                    .add(notificationData)
                    .addOnSuccessListener {
                        Log.d("AppBlocked", "✅ Notificación enviada al padre")
                        Toast.makeText(this, "✅ Solicitud enviada al padre", Toast.LENGTH_LONG).show()

                        // Cerrar después de éxito
                        handler.postDelayed({
                            removeOverlay()
                            returnToHome()
                        }, 2000)
                    }
                    .addOnFailureListener { e ->
                        Log.e("AppBlocked", "❌ Error en notificación: ${e.message}")
                        Toast.makeText(this, "Solicitud enviada, pero error en notificación", Toast.LENGTH_LONG).show()
                    }
            }
            .addOnFailureListener { e ->
                Log.e("AppBlocked", "❌ Error en solicitud: ${e.message}")
                Toast.makeText(this, "Error al enviar solicitud: ${e.message}", Toast.LENGTH_LONG).show()
            }
    }

    private fun removeOverlay() {
        try {
            overlayView?.let {
                windowManager?.removeView(it)
                Log.d("AppBlocked", "🗑️ Overlay removido")
            }
            overlayView = null
        } catch (e: Exception) {
            Log.e("AppBlocked", "❌ Error removiendo overlay: ${e.message}")
        }
    }

    private fun setupBackPressedHandler() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                Log.d("AppBlocked", "⬅️ Back pressed")
                removeOverlay()
                returnToHome()
            }
        })
    }

    private fun returnToHome() {
        try {
            val homeIntent = Intent(Intent.ACTION_MAIN).apply {
                addCategory(Intent.CATEGORY_HOME)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            startActivity(homeIntent)
            finish()
            Log.d("AppBlocked", "🏠 Volviendo al inicio")
        } catch (e: Exception) {
            Log.e("AppBlocked", "❌ Error volviendo al inicio", e)
            finish()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        removeOverlay()
        handler.removeCallbacksAndMessages(null)
        Log.d("AppBlocked", "🛑 Actividad destruida")
    }
}