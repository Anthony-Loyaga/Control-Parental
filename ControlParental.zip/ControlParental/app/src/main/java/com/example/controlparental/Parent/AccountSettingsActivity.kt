package com.example.controlparental.Parent

import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AccountSettingsActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var btnBack: ImageButton
    private lateinit var etParentName: TextInputEditText
    private lateinit var etParentEmail: TextInputEditText
    private lateinit var btnSaveChanges: MaterialButton
    private lateinit var rvChildren: RecyclerView
    private lateinit var tvNoChildren: TextView

    private lateinit var childrenAdapter: ChildrenAdapter
    private val childrenList = mutableListOf<Child>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_account_settings)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        initViews()
        loadParentData()
        loadChildren()
        setupClickListeners()
    }

    private fun initViews() {
        btnBack = findViewById(R.id.btnBack)
        etParentName = findViewById(R.id.etParentName)
        etParentEmail = findViewById(R.id.etParentEmail)
        btnSaveChanges = findViewById(R.id.btnSaveChanges)
        rvChildren = findViewById(R.id.rvChildren)
        tvNoChildren = findViewById(R.id.tvNoChildren)

        // Configurar RecyclerView
        childrenAdapter = ChildrenAdapter(childrenList) { child ->
            showChildOptionsDialog(child)
        }
        rvChildren.layoutManager = LinearLayoutManager(this)
        rvChildren.adapter = childrenAdapter
    }

    private fun loadParentData() {
        val currentUser = auth.currentUser
        currentUser?.let { user ->
            etParentEmail.setText(user.email)

            // Cargar nombre desde Firestore
            db.collection("users").document(user.uid)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val name = document.getString("name") ?: ""
                        etParentName.setText(name)
                    }
                }
        }
    }

    private fun loadChildren() {
        val parentId = auth.currentUser?.uid ?: return

        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .get()
            .addOnSuccessListener { documents ->
                childrenList.clear()
                for (document in documents) {
                    val childId = document.getString("childId") ?: continue

                    // Obtener información detallada del hijo
                    db.collection("users").document(childId)
                        .get()
                        .addOnSuccessListener { childDocument ->
                            if (childDocument.exists()) {
                                val child = Child(
                                    id = childId,
                                    name = childDocument.getString("name") ?: "Hijo",
                                    email = childDocument.getString("email") ?: "",
                                    birthDate = childDocument.getString("birthDate") ?: "",
                                    age = childDocument.getLong("age")?.toInt() ?: 0,
                                    gender = childDocument.getString("gender") ?: "",
                                    school = childDocument.getString("school") ?: "No especificado",
                                    grade = childDocument.getString("grade") ?: "No especificado"
                                )
                                childrenList.add(child)
                                childrenAdapter.notifyDataSetChanged()
                                updateChildrenVisibility()
                            }
                        }
                }
                updateChildrenVisibility()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar hijos: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun updateChildrenVisibility() {
        if (childrenList.isEmpty()) {
            rvChildren.visibility = android.view.View.GONE
            tvNoChildren.visibility = android.view.View.VISIBLE
        } else {
            rvChildren.visibility = android.view.View.VISIBLE
            tvNoChildren.visibility = android.view.View.GONE
        }
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnSaveChanges.setOnClickListener {
            saveParentInfo()
        }
    }

    private fun saveParentInfo() {
        val newName = etParentName.text.toString().trim()
        if (newName.isEmpty()) {
            etParentName.error = "Ingresa un nombre"
            return
        }

        val currentUser = auth.currentUser
        currentUser?.let { user ->
            db.collection("users").document(user.uid)
                .update("name", newName)
                .addOnSuccessListener {
                    // Actualizar SessionManager
                    SessionManager.saveUserName(this, newName)
                    Toast.makeText(this, "Información actualizada correctamente", Toast.LENGTH_SHORT).show()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Error al actualizar: ${e.message}", Toast.LENGTH_SHORT).show()
                }
        }
    }

    private fun showChildOptionsDialog(child: Child) {
        val options = arrayOf("Ver Detalles", "Editar Información", "Eliminar Vinculo")

        MaterialAlertDialogBuilder(this)
            .setTitle("Opciones para ${child.name}")
            .setItems(options) { dialog, which ->
                when (which) {
                    0 -> showChildDetails(child)
                    1 -> editChildInfo(child)
                    2 -> showRemoveChildConfirmation(child)
                }
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun showChildDetails(child: Child) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Detalles de ${child.name}")
            .setMessage(
                "Nombre: ${child.name}\n" +
                        "Email: ${child.email}\n" +
                        "Edad: ${child.age} años\n" +
                        "Fecha Nacimiento: ${child.birthDate}\n" +
                        "Género: ${child.gender}\n" +
                        "Escuela: ${child.school}\n" +
                        "Grado: ${child.grade}"
            )
            .setPositiveButton("Aceptar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun editChildInfo(child: Child) {
        val intent = Intent(this, EditChildActivity::class.java).apply {
            putExtra("CHILD_ID", child.id)
        }
        startActivity(intent)
    }

    private fun showRemoveChildConfirmation(child: Child) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Eliminar Vínculo")
            .setMessage("¿Estás seguro de que quieres eliminar el vínculo con ${child.name}?")
            .setPositiveButton("Eliminar") { dialog, _ ->
                removeChild(child)
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .show()
    }

    private fun removeChild(child: Child) {
        val parentId = auth.currentUser?.uid ?: return

        db.collection("guardianships")
            .document("${parentId}_${child.id}")
            .delete()
            .addOnSuccessListener {
                childrenList.remove(child)
                childrenAdapter.notifyDataSetChanged()
                updateChildrenVisibility()
                Toast.makeText(this, "Vínculo eliminado correctamente", Toast.LENGTH_SHORT).show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al eliminar vínculo: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    data class Child(
        val id: String,
        val name: String,
        val email: String,
        val birthDate: String,
        val age: Int,
        val gender: String,
        val school: String,
        val grade: String
    )
}