package com.example.controlparental.children

import android.app.ActivityManager
import android.app.AlertDialog
import android.app.AppOpsManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.net.VpnService
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.Process
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.children.AppBlockedActivity
import com.example.controlparental.BlockedAppAdapter
import com.example.controlparental.Parent.Helper.LocationHelper
import com.example.controlparental.R
import com.example.controlparental.children.services.AppBlockerService
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions

class ChildHomeActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var rvLimitedApps: RecyclerView
    private lateinit var rvBlockedApps: RecyclerView
    private var blockedAppsListener: ListenerRegistration? = null
    private var currentChildId: String? = null

    // Broadcast receiver para recibir bloqueos del servicio
    private val blockReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("ChildHome", "📨 Broadcast recibido: ${intent?.action}")

            if (intent?.action == "APP_BLOCK_ACTION") {
                val packageName = intent.getStringExtra("packageName") ?: return
                val appName = intent.getStringExtra("appName") ?: packageName

                Log.d("ChildHome", "🛑 Recibido bloqueo para: $appName")

                initViews()
                initFirebase()
                setupBroadcastReceivers()
                startServices()
                showBlockScreen(packageName, appName)
                checkPermissionsAndStartService()
                abortBroadcast()
            }
        }
    }

    // Broadcast receiver de emergencia
    private val emergencyReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            Log.d("ChildHome", "🆘 Broadcast de emergencia recibido: ${intent?.action}")

            if (intent?.action == "APP_BLOCK_EMERGENCY") {
                val packageName = intent.getStringExtra("packageName") ?: return
                val appName = intent.getStringExtra("appName") ?: packageName

                Log.d("ChildHome", "🆘 Mostrando bloqueo de emergencia para: $appName")
                showBlockScreen(packageName, appName)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_home)

        initViews()
        initFirebase()
        setupBroadcastReceivers()
        startServices()

        Log.d("ChildHome", "✅ Activity creada")
    }

    private fun initViews() {
        rvLimitedApps = findViewById(R.id.rvLimitedApps)
        rvLimitedApps.layoutManager = LinearLayoutManager(this)
        rvLimitedApps.isNestedScrollingEnabled = false

        rvBlockedApps = findViewById(R.id.rvBlockedApps)
        rvBlockedApps.layoutManager = LinearLayoutManager(this)
        rvBlockedApps.isNestedScrollingEnabled = false
    }

    private fun initFirebase() {
        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val childId = auth.currentUser?.uid
        if (childId == null) {
            finish()
            return
        }
        currentChildId = childId

        showChildName(childId)
        registerInstalledApps(childId)
        listenForBlockedApps()
    }

    private fun setupBroadcastReceivers() {
        // Configurar receiver normal
        try {
            val filter = IntentFilter("APP_BLOCK_ACTION")
            filter.priority = IntentFilter.SYSTEM_HIGH_PRIORITY
            registerReceiver(blockReceiver, filter, RECEIVER_EXPORTED)
            Log.d("ChildHome", "📨 Broadcast receiver registrado con alta prioridad")
        } catch (e: Exception) {
            Log.e("ChildHome", "❌ Error registrando receiver normal", e)
        }

        // Configurar receiver de emergencia
        try {
            val emergencyFilter = IntentFilter("APP_BLOCK_EMERGENCY")
            registerReceiver(emergencyReceiver, emergencyFilter, RECEIVER_EXPORTED)
            Log.d("ChildHome", "🆘 Receiver de emergencia registrado")
        } catch (e: Exception) {
            Log.e("ChildHome", "❌ Error registrando receiver de emergencia", e)
        }
    }

    private fun startServices() {
        startAppBlockerService()
        checkUsagePermission()
        checkOverlayPermission()

    }

    private fun showBlockScreen(packageName: String, appName: String) {
        Log.d("ChildHome", "🖥️ Mostrando pantalla de bloqueo para: $appName")

        runOnUiThread {
            try {
                val intent = Intent(this, AppBlockedActivity::class.java).apply {
                    putExtra("packageName", packageName)
                    putExtra("appName", appName)
                    addFlags(
                        Intent.FLAG_ACTIVITY_NEW_TASK or
                            Intent.FLAG_ACTIVITY_CLEAR_TOP or
                            Intent.FLAG_ACTIVITY_SINGLE_TOP)
                }
                startActivity(intent)

                Toast.makeText(this, "🔒 $appName bloqueada", Toast.LENGTH_SHORT).show()

                // Log de diagnóstico
                Log.d("ChildHome", "✅ Pantalla de bloqueo lanzada exitosamente")

            } catch (e: Exception) {
                Log.e("ChildHome", "❌ Error mostrando pantalla de bloqueo", e)
                Toast.makeText(this, "Error bloqueando app", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun startAppBlockerService() {
        try {
            val intent = Intent(this, AppBlockerService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(intent)
            } else {
                startService(intent)
            }
            Log.d("ChildHome", "🚀 Servicio iniciado")

            // Verificar después de 3 segundos
            Handler(Looper.getMainLooper()).postDelayed({
                checkIfServiceIsRunning()
            }, 3000)

        } catch (e: Exception) {
            Log.e("ChildHome", "❌ Error iniciando servicio", e)
        }
    }

    private fun checkIfServiceIsRunning() {
        val isRunning = isMyServiceRunning(AppBlockerService::class.java)
        if (isRunning) {
            Log.d("ChildHome", "✅✅✅ SERVICIO ACTIVO")
            Toast.makeText(this, "🛡️ Protección activa", Toast.LENGTH_SHORT).show()
        } else {
            Log.e("ChildHome", "❌❌❌ SERVICIO INACTIVO")
            Toast.makeText(this, "⚠️ Protección inactiva", Toast.LENGTH_SHORT).show()
        }
    }

    private fun isMyServiceRunning(serviceClass: Class<*>): Boolean {
        try {
            val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
            @Suppress("DEPRECATION")
            val runningServices = manager.getRunningServices(Integer.MAX_VALUE)

            for (service in runningServices) {
                if (serviceClass.name == service.service.className) {
                    return true
                }
            }
        } catch (e: Exception) {
            Log.e("ChildHome", "❌ Error verificando servicio", e)
        }
        return false
    }

    private fun checkUsagePermission() {
        if (!hasUsageAccessPermission()) {
            val intent = Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Permite el acceso de uso", Toast.LENGTH_LONG).show()
        } else {
            Log.d("ChildHome", "✅ Permiso de uso concedido")
        }
    }

    private fun checkOverlayPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "Permite mostrar sobre otras apps", Toast.LENGTH_LONG).show()
            } else {
                Log.d("ChildHome", "✅ Permiso overlay concedido")
            }
        }
    }

    private fun hasUsageAccessPermission(): Boolean {
        return try {
            val appOps = getSystemService(APP_OPS_SERVICE) as AppOpsManager
            val mode = appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                packageName
            )
            mode == AppOpsManager.MODE_ALLOWED
        } catch (e: Exception) {
            Log.e("ChildHome", "❌ Error verificando permiso", e)
            false
        }
    }

    private fun listenForBlockedApps() {
        currentChildId?.let { childId ->
            blockedAppsListener = db.collection("children/$childId/apps")
                .whereEqualTo("isBlocked", true)
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.e("ChildHome", "❌ Error escuchando apps bloqueadas", error)
                        return@addSnapshotListener
                    }

                    val blockedAppNames = mutableListOf<String>()
                    snapshot?.documents?.forEach { document ->
                        val appName = document.getString("name") ?: document.id
                        blockedAppNames.add(appName)
                    }

                    rvBlockedApps.adapter = BlockedAppAdapter(blockedAppNames)
                    Log.d("ChildHome", "🔄 Apps bloqueadas: ${blockedAppNames.size}")

                    // Mostrar en Toast para debug
                    if (blockedAppNames.isNotEmpty()) {
                        Toast.makeText(this, "Apps bloqueadas: ${blockedAppNames.size}", Toast.LENGTH_SHORT).show()
                    }
                }
        }
    }

    private fun showChildName(childId: String) {
        db.collection("users").document(childId).get()
            .addOnSuccessListener { doc ->
                val name = doc.getString("name") ?: "Hijo"
                findViewById<TextView>(R.id.tvWelcome).text = "HOLA, $name! ESPERO QUE TE ENCUENTRES BIEN"
            }
            .addOnFailureListener { e ->
                Log.e("ChildHome", "❌ Error obteniendo nombre", e)
                findViewById<TextView>(R.id.tvWelcome).text = "HOLA! ESPERO QUE TE ENCUENTRES BIEN"
            }
    }

    private fun registerInstalledApps(childId: String) {

        val installedApps = packageManager.getInstalledApplications(0)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }  // Solo apps del usuario

        val installedPackageNames = installedApps.map { it.packageName }.toSet()

        val appsRef = db.collection("children/$childId/apps")

        // 1️⃣ OBTENER apps actuales en la base de datos
        appsRef.get().addOnSuccessListener { snapshot ->

            val existingDocs = snapshot.documents.associateBy { it.id }
            val batch = db.batch()

            // 2️⃣ AGREGAR SOLO apps nuevas
            for (app in installedApps) {
                val packageName = app.packageName

                if (!existingDocs.containsKey(packageName)) {
                    val appName = app.loadLabel(packageManager).toString()

                    val data = mapOf(
                        "name" to appName,
                        "category" to "General",
                        "isBlocked" to false,          // No tocar
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    batch.set(
                        appsRef.document(packageName),
                        data,
                        SetOptions.merge()
                    )

                    Log.d("ChildHome", "🟢 Nueva app agregada: $appName")
                }
            }

            // 3️⃣ ELIMINAR apps que ya no existen en el dispositivo
            val appsToDelete = existingDocs.keys.filter { it !in installedPackageNames }

            for (packageName in appsToDelete) {
                batch.delete(appsRef.document(packageName))
                Log.d("ChildHome", "🟠 App eliminada del dispositivo → Eliminada de Firebase: $packageName")
            }

            // 4️⃣ EJECUTAR Batch
            batch.commit()
                .addOnSuccessListener {
                    Log.d("ChildHome", "✅ Sincronización completa (agregadas nuevas + eliminadas no instaladas)")
                }
                .addOnFailureListener { e ->
                    Log.e("ChildHome", "❌ Error en sincronización de apps", e)
                }

        }.addOnFailureListener { e ->
            Log.e("ChildHome", "❌ Error leyendo apps de Firebase", e)
        }
    }


    private fun ensureAppIconsExist(appEntries: List<Pair<String, String>>) {
        if (appEntries.isEmpty()) return

        var completed = 0
        val total = appEntries.size

        for ((packageName, appName) in appEntries) {
            db.collection("app_icons").document(packageName).get()
                .addOnSuccessListener { document ->
                    if (!document.exists()) {
                        val iconData = mapOf(
                            "iconUrl" to null,
                            "category" to "General",
                            "name" to appName
                        )
                        db.collection("app_icons").document(packageName)
                            .set(iconData)
                            .addOnSuccessListener {
                                Log.d("ChildHome", "🆕 Creado app_icons/$packageName")
                            }
                            .addOnFailureListener { e ->
                                Log.e("ChildHome", "❌ Error al crear app_icons/$packageName", e)
                            }
                    }
                }
                .addOnFailureListener { e ->
                    Log.e("ChildHome", "❌ Error al verificar app_icons/$packageName", e)
                }
                .addOnCompleteListener {
                    completed++
                    if (completed == total) {
                        Log.d("ChildHome", "✅ Proceso de app_icons completado")
                    }
                }
        }
    }


    private fun checkAppVisibility() {
        Log.d("ChildHome", "🔍 Diagnóstico de visibilidad:")
        Log.d("ChildHome", "🔍 - Activity visible: ${!isFinishing && !isDestroyed}")
        Log.d("ChildHome", "🔍 - Receivers registrados: ✅")
    }


    fun onForceStartClick(view: View) {
        Log.d("ChildHome", "🔄 Forzando inicio del servicio")
        startAppBlockerService()
    }

    override fun onResume() {
        super.onResume()
        Log.d("ChildHome", "🔄 Activity reanudada")
        checkPermissionsAndStartService()
        checkUsagePermission()
        checkOverlayPermission()
        checkAppVisibility()

    }

    override fun onPause() {
        super.onPause()
        Log.d("ChildHome", "⏸️ Activity pausada")
    }
    private fun showLocationSettingsDialog() {
        AlertDialog.Builder(this)
            .setTitle("Ubicación requerida")
            .setMessage("El monitoreo de ubicación requiere que el GPS esté activado")
            .setPositiveButton("Activar") { _, _ ->
                val intent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(intent)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    private fun checkPermissionsAndStartService() {
        if (!LocationHelper.checkLocationPermission(this)) {
            LocationHelper.requestLocationPermission(this)
        } else if (!LocationHelper.isLocationEnabled(this)) {
            showLocationSettingsDialog()
        } else {
            // Iniciar el servicio de ubicación
            LocationHelper.startLocationService(this)
        }
    }

    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<out String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)

        if (requestCode == LocationHelper.LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                LocationHelper.startLocationService(this)
            } else {
                Toast.makeText(this, "Los permisos de ubicación son necesarios", Toast.LENGTH_LONG).show()
            }
        }
    }
    override fun onDestroy() {
        super.onDestroy()
        // Limpiar listeners y receivers
        blockedAppsListener?.remove()
        try {
            unregisterReceiver(blockReceiver)
        } catch (e: Exception) {
            // Ignorar si no estaba registrado
        }
        try {
            unregisterReceiver(emergencyReceiver)
        } catch (e: Exception) {
            // Ignorar si no estaba registrado
        }
        Log.d("ChildHome", "🛑 Activity destruida")
    }
}