package com.example.controlparental.parent.services

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.controlparental.Parent.UnlockRequestActivity
import com.example.controlparental.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*

class ParentNotificationService : Service() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private var notificationListener: ListenerRegistration? = null
    private var parentId: String? = null
    private var notificationIdCounter = 1000

    companion object {
        private const val CHANNEL_ID = "parent_notif_channel"
        private const val SERVICE_NOTIFICATION_ID = 456
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("ParentNotifService", "🟢 Servicio de notificaciones creado")

        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        parentId = auth.currentUser?.uid

        if (parentId == null) {
            Log.e("ParentNotifService", "❌ No hay usuario autenticado")
            stopSelf()
            return
        }

        createNotificationChannel()
        startForegroundService()
        startListening()
    }

    private fun startForegroundService() {
        try {
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Control Parental - Padre")
                .setContentText("Monitoreando solicitudes de desbloqueo")
                .setSmallIcon(R.drawable.ic_menu_add_background)
                .setPriority(NotificationCompat.PRIORITY_LOW)
                .setOngoing(true)
                .setAutoCancel(false)
                .setSilent(true)
                .build()

            startForeground(SERVICE_NOTIFICATION_ID, notification)
            Log.d("ParentNotifService", "✅ Servicio en primer plano iniciado")
        } catch (e: Exception) {
            Log.e("ParentNotifService", "❌ Error en foreground service", e)
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Notificaciones Control Parental",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Notificaciones de solicitudes de desbloqueo"
                enableLights(true)
                enableVibration(true)
                setShowBadge(true)
            }

            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
            Log.d("ParentNotifService", "✅ Canal de notificaciones creado")
        }
    }

    private fun startListening() {
        parentId ?: return

        Log.d("ParentNotifService", "🔊 Iniciando listener para parent: $parentId")

        notificationListener = db.collection("parents/$parentId/notificaciones")
            .whereEqualTo("viewed", false)
            .addSnapshotListener { snapshots, error ->
                if (error != null) {
                    Log.e("ParentNotifService", "❌ Error en listener: ${error.message}")
                    return@addSnapshotListener
                }

                Log.d("ParentNotifService", "📄 Snapshot recibido, ${snapshots?.size()} documentos")

                snapshots?.documentChanges?.forEach { change ->
                    Log.d("ParentNotifService", "🔄 Tipo de cambio: ${change.type}")

                    if (change.type == DocumentChange.Type.ADDED) {
                        val notif = change.document
                        val title = notif.getString("title") ?: "Notificación"
                        val message = notif.getString("message") ?: ""
                        val childId = notif.getString("childId") ?: ""
                        val childName = notif.getString("childName") ?: ""
                        val appName = notif.getString("appName") ?: ""
                        val packageName = notif.getString("packageName") ?: ""
                        val requestId = notif.getString("requestId") ?: ""
                        val notifId = notif.id
                        val type = notif.getString("type") ?: "unlock_request"

                        Log.d("ParentNotifService", "📨 Nueva notificación: $title - $message")

                        // Mostrar notificación local
                        showLocalNotification(title, message, childId, childName, appName, packageName, requestId, type)

                        // Marcar como vista en Firestore
                        markNotificationAsViewed(notifId)
                    }
                }
            }
    }

    private fun showLocalNotification(
        title: String,
        message: String,
        childId: String,
        childName: String,
        appName: String,
        packageName: String,
        requestId: String,
        type: String
    ) {
        try {
            val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

            // Verificar si las notificaciones están habilitadas
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = notificationManager.getNotificationChannel(CHANNEL_ID)
                if (channel.importance == NotificationManager.IMPORTANCE_NONE) {
                    Log.e("ParentNotifService", "❌ Canal de notificaciones deshabilitado por el usuario")
                    return
                }
            }

            // Intent para abrir UnlockRequestActivity
            val intent = Intent(this, UnlockRequestActivity::class.java).apply {
                putExtra("childId", childId)
                putExtra("childName", childName)
                putExtra("appName", appName)
                putExtra("packageName", packageName)
                putExtra("requestId", requestId)
                putExtra("type", type)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }

            val pendingIntent = PendingIntent.getActivity(
                this,
                notificationIdCounter++,
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            // Construir la notificación
            val notification = NotificationCompat.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_menu_add_background)
                .setContentTitle(title)
                .setContentText(message)
                .setStyle(NotificationCompat.BigTextStyle().bigText(message))
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setDefaults(NotificationCompat.DEFAULT_ALL) // Sonido, vibración, LED
                .setCategory(NotificationCompat.CATEGORY_ALARM)
                .build()

            // Mostrar notificación
            val notificationId = System.currentTimeMillis().toInt()
            notificationManager.notify(notificationId, notification)

            Log.d("ParentNotifService", "📤 Notificación mostrada - ID: $notificationId, Título: $title")

        } catch (e: Exception) {
            Log.e("ParentNotifService", "❌ Error mostrando notificación: ${e.message}")
        }
    }

    private fun markNotificationAsViewed(notifId: String) {
        parentId ?: return

        db.collection("parents/$parentId/notificaciones")
            .document(notifId)
            .update("viewed", true)
            .addOnSuccessListener {
                Log.d("ParentNotifService", "✅ Notificación marcada como vista: $notifId")
            }
            .addOnFailureListener { e ->
                Log.e("ParentNotifService", "❌ Error marcando notificación como vista: ${e.message}")
            }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("ParentNotifService", "🚀 onStartCommand ejecutado")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d("ParentNotifService", "🛑 Servicio destruido")
        notificationListener?.remove()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}