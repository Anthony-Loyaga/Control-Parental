package com.example.controlparental.Parent.Helper

import android.Manifest
import android.app.Activity
import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import android.util.Log
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.controlparental.children.services.LocationTrackerService

object LocationHelper {

    const val LOCATION_PERMISSION_REQUEST_CODE = 1001

    fun checkLocationPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    context,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
    }

    fun requestLocationPermission(activity: Activity) {
        val permissions = arrayOf(
            Manifest.permission.ACCESS_FINE_LOCATION,
            Manifest.permission.ACCESS_COARSE_LOCATION
        )

        ActivityCompat.requestPermissions(
            activity,
            permissions,
            LOCATION_PERMISSION_REQUEST_CODE
        )
    }

    fun startLocationService(context: Context) {
        if (!checkLocationPermission(context)) {
            Toast.makeText(context, "Se necesitan permisos de ubicación", Toast.LENGTH_SHORT).show()
            return
        }

        val serviceIntent = Intent(context, LocationTrackerService::class.java)

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
            Toast.makeText(context, "Monitoreo de ubicación iniciado", Toast.LENGTH_SHORT).show()
            Log.d("LocationHelper", "✅ Servicio de ubicación iniciado")
        } catch (e: Exception) {
            Log.e("LocationHelper", "❌ Error iniciando servicio", e)
            Toast.makeText(context, "Error iniciando servicio de ubicación", Toast.LENGTH_SHORT).show()
        }
    }

    fun stopLocationService(context: Context) {
        val serviceIntent = Intent(context, LocationTrackerService::class.java)
        context.stopService(serviceIntent)
        Toast.makeText(context, "Monitoreo de ubicación detenido", Toast.LENGTH_SHORT).show()
        Log.d("LocationHelper", "🛑 Servicio de ubicación detenido")
    }

    fun isLocationEnabled(context: Context): Boolean {
        return try {
            val locationMode = Settings.Secure.getInt(
                context.contentResolver,
                Settings.Secure.LOCATION_MODE
            )
            locationMode != Settings.Secure.LOCATION_MODE_OFF
        } catch (e: Exception) {
            // Para Android 10+
            val locationProviders = Settings.Secure.getString(
                context.contentResolver,
                Settings.Secure.LOCATION_PROVIDERS_ALLOWED
            )
            !locationProviders.isNullOrEmpty()
        }
    }

    fun isLocationServiceRunning(context: Context): Boolean {
        val manager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        return manager.getRunningServices(Integer.MAX_VALUE)
            .any { it.service.className == LocationTrackerService::class.java.name }
    }
}