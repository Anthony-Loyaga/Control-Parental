package com.example.controlparental.Parent

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.R

class ChildrenAdapter(
    private val children: List<AccountSettingsActivity.Child>,
    private val onChildClick: (AccountSettingsActivity.Child) -> Unit
) : RecyclerView.Adapter<ChildrenAdapter.ChildViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChildViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_child, parent, false)
        return ChildViewHolder(view)
    }

    override fun onBindViewHolder(holder: ChildViewHolder, position: Int) {
        val child = children[position]
        holder.bind(child)
        holder.itemView.setOnClickListener { onChildClick(child) }
    }

    override fun getItemCount(): Int = children.size

    class ChildViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val tvChildName: TextView = itemView.findViewById(R.id.tvChildName)
        private val tvChildAge: TextView = itemView.findViewById(R.id.tvChildAge)
        private val tvChildSchool: TextView = itemView.findViewById(R.id.tvChildSchool)

        fun bind(child: AccountSettingsActivity.Child) {
            tvChildName.text = child.name
            tvChildAge.text = "Edad: ${child.age} años"
            tvChildSchool.text = child.school
        }
    }
}