package com.example.controlparental.Parent

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ImageButton
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class EditChildActivity : AppCompatActivity() {

    private lateinit var db: FirebaseFirestore
    private lateinit var etChildName: TextInputEditText
    private lateinit var etChildEmail: TextInputEditText
    private lateinit var etBirthDate: TextInputEditText
    private lateinit var etAge: TextInputEditText
    private lateinit var spinnerGender: Spinner
    private lateinit var btnSave: MaterialButton
    private lateinit var btnCancel: MaterialButton
    private lateinit var btnBack: ImageButton

    private var childId: String = ""
    private val calendar = Calendar.getInstance()
    private var selectedBirthDate: Calendar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_child)

        db = FirebaseFirestore.getInstance()

        // Obtener datos del hijo del intent
        childId = intent.getStringExtra("CHILD_ID") ?: ""
        if (childId.isEmpty()) {
            Toast.makeText(this, "Error: No se pudo cargar la información del hijo", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        initViews()
        setupGenderSpinner()
        setupDatePicker()
        loadChildData()
        setupClickListeners()
    }

    private fun initViews() {
        try {
            etChildName = findViewById(R.id.etChildName)
            etChildEmail = findViewById(R.id.etChildEmail)
            etBirthDate = findViewById(R.id.etBirthDate)
            etAge = findViewById(R.id.etAge)
            spinnerGender = findViewById(R.id.spinnerGender)
            btnSave = findViewById(R.id.btnSave)
            btnCancel = findViewById(R.id.btnCancel)
            btnBack = findViewById(R.id.btnBack) // Ahora existe en el layout

            // Verificar que todas las vistas fueron encontradas
            if (etChildName == null || etChildEmail == null || etBirthDate == null ||
                etAge == null || spinnerGender == null || btnSave == null ||
                btnCancel == null || btnBack == null) {
                throw NullPointerException("Alguna vista no fue encontrada")
            }
        } catch (e: Exception) {
            Toast.makeText(this, "Error al inicializar vistas: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun setupGenderSpinner() {
        val genders = arrayOf("Seleccionar género", "Masculino", "Femenino", "Otro", "Prefiero no decir")
        val adapter = ArrayAdapter<String>(this, R.layout.spinner_item, genders)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        spinnerGender.adapter = adapter
    }

    private fun setupDatePicker() {
        etBirthDate.setOnClickListener {
            showDatePicker()
        }
    }

    private fun showDatePicker() {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                selectedBirthDate = Calendar.getInstance().apply {
                    set(selectedYear, selectedMonth, selectedDay)
                }

                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                etBirthDate.setText(sdf.format(selectedBirthDate!!.time))

                // Calcular la edad automáticamente
                calculateAge()
            },
            year, month, day
        )

        // Establecer fecha máxima como hoy
        datePickerDialog.datePicker.maxDate = calendar.timeInMillis

        // Establecer fecha mínima (hace 18 años)
        val minDate = Calendar.getInstance().apply {
            add(Calendar.YEAR, -18)
        }
        datePickerDialog.datePicker.minDate = minDate.timeInMillis

        datePickerDialog.show()
    }

    private fun calculateAge() {
        selectedBirthDate?.let { birthDate ->
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR)

            if (today.get(Calendar.DAY_OF_YEAR) < birthDate.get(Calendar.DAY_OF_YEAR)) {
                age--
            }

            etAge.setText(age.toString())
        }
    }

    private fun loadChildData() {
        db.collection("users").document(childId)
            .get()
            .addOnSuccessListener { document ->
                if (document.exists()) {
                    etChildName.setText(document.getString("name"))
                    etChildEmail.setText(document.getString("email"))

                    val birthDate = document.getString("birthDate")
                    etBirthDate.setText(birthDate ?: "")

                    val age = document.getLong("age")?.toString() ?: ""
                    etAge.setText(age)

                    // Configurar género
                    val gender = document.getString("gender")
                    if (!gender.isNullOrEmpty()) {
                        try {
                            val adapter = spinnerGender.adapter as ArrayAdapter<String>
                            val position = adapter.getPosition(gender)
                            if (position >= 0) {
                                spinnerGender.setSelection(position)
                            } else {
                                spinnerGender.setSelection(0)
                            }
                        } catch (e: Exception) {
                            spinnerGender.setSelection(0)
                        }
                    }

                    // Si hay fecha de nacimiento, establecer selectedBirthDate
                    if (!birthDate.isNullOrEmpty()) {
                        val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                        try {
                            val date = sdf.parse(birthDate)
                            selectedBirthDate = Calendar.getInstance().apply {
                                time = date
                            }
                        } catch (e: Exception) {
                            e.printStackTrace()
                        }
                    }
                } else {
                    Toast.makeText(this, "No se encontró la información del hijo", Toast.LENGTH_SHORT).show()
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar datos: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun setupClickListeners() {
        btnBack.setOnClickListener {
            finish()
        }

        btnCancel.setOnClickListener {
            finish()
        }

        btnSave.setOnClickListener {
            saveChildInfo()
        }
    }

    private fun saveChildInfo() {
        val name = etChildName.text.toString().trim()
        val birthDate = etBirthDate.text.toString().trim()
        val ageStr = etAge.text.toString().trim()
        val gender = spinnerGender.selectedItem.toString()

        // Validaciones
        if (name.isEmpty()) {
            etChildName.error = "Ingresa el nombre del niño"
            etChildName.requestFocus()
            return
        }

        if (birthDate.isEmpty()) {
            etBirthDate.error = "Selecciona la fecha de nacimiento"
            etBirthDate.requestFocus()
            return
        }

        if (ageStr.isEmpty()) {
            etAge.error = "La edad es requerida"
            etAge.requestFocus()
            return
        }

        if (gender == "Seleccionar género") {
            Toast.makeText(this, "Selecciona un género", Toast.LENGTH_SHORT).show()
            return
        }

        val age = try {
            ageStr.toInt()
        } catch (e: NumberFormatException) {
            etAge.error = "La edad debe ser un número válido"
            etAge.requestFocus()
            return
        }

        if (age < 3 || age > 18) {
            etAge.error = "La edad debe estar entre 3 y 18 años"
            etAge.requestFocus()
            return
        }

        // Mostrar estado de carga
        btnSave.isEnabled = false
        btnSave.text = "Guardando..."

        val childData = hashMapOf<String, Any>(
            "name" to name,
            "birthDate" to birthDate,
            "age" to age,
            "gender" to gender,
            "updatedAt" to FieldValue.serverTimestamp()
        )

        db.collection("users").document(childId)
            .update(childData)
            .addOnSuccessListener {
                Toast.makeText(this, "Información actualizada correctamente", Toast.LENGTH_SHORT).show()

                // También actualizar en guardianships si es necesario
                updateGuardianshipName(name)

                setResult(RESULT_OK)
                finish()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al actualizar: ${e.message}", Toast.LENGTH_SHORT).show()
                btnSave.isEnabled = true
                btnSave.text = "Guardar Cambios"
            }
    }

    private fun updateGuardianshipName(childName: String) {
        val parentId = SessionManager.getParentId(this)
        parentId?.let { pid ->
            val guardianshipId = "${pid}_$childId"
            db.collection("guardianships").document(guardianshipId)
                .update("childName", childName)
                .addOnSuccessListener {
                    // Actualizado exitosamente
                }
                .addOnFailureListener { e ->
                    android.util.Log.e("EditChildActivity", "Error al actualizar guardianship: ${e.message}")
                }
        }
    }
}