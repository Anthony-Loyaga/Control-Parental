package com.example.controlparental.Parent

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.util.Patterns
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.android.material.textfield.TextInputEditText
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

class RegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var etName: TextInputEditText
    private lateinit var etEmail: TextInputEditText
    private lateinit var etPassword: TextInputEditText
    private lateinit var etConfirmPassword: TextInputEditText
    private lateinit var btnRegister: Button
    private lateinit var tvGoToLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        // Vincular vistas
        etName = findViewById(R.id.etName)
        etEmail = findViewById(R.id.etEmail)
        etPassword = findViewById(R.id.etPassword)
        etConfirmPassword = findViewById(R.id.etConfirmPassword)
        btnRegister = findViewById(R.id.btnRegister)
        tvGoToLogin = findViewById(R.id.tvGoToLogin)

        // Configurar acciones
        btnRegister.setOnClickListener { registerUser() }
        tvGoToLogin.setOnClickListener {
            finish() // Regresa al login
        }
    }

    private fun registerUser() {
        val name = etName.text.toString().trim()
        val email = etEmail.text.toString().trim()
        val password = etPassword.text.toString()
        val confirmPassword = etConfirmPassword.text.toString()

        // Validaciones
        if (!validateForm(name, email, password, confirmPassword)) {
            return
        }

        // Mostrar estado de carga
        setLoadingState(true)

        // Registrar en Firebase Authentication
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                setLoadingState(false)

                if (task.isSuccessful) {
                    // Registro exitoso
                    val user = auth.currentUser
                    saveUserProfile(user, name, email)
                } else {
                    // Error
                    val errorMessage = task.exception?.message ?: "Error desconocido"
                    showError("Error al crear cuenta: $errorMessage")
                }
            }
    }

    private fun validateForm(name: String, email: String, password: String, confirmPassword: String): Boolean {
        // Resetear errores
        etName.error = null
        etEmail.error = null
        etPassword.error = null
        etConfirmPassword.error = null

        var isValid = true

        if (name.isEmpty()) {
            etName.error = "Ingresa tu nombre completo"
            etName.requestFocus()
            isValid = false
        } else if (name.length < 2) {
            etName.error = "El nombre debe tener al menos 2 caracteres"
            etName.requestFocus()
            isValid = false
        }

        if (email.isEmpty()) {
            etEmail.error = "Ingresa tu correo electrónico"
            if (isValid) etEmail.requestFocus()
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.error = "Correo electrónico inválido"
            if (isValid) etEmail.requestFocus()
            isValid = false
        }

        if (password.isEmpty()) {
            etPassword.error = "Ingresa una contraseña"
            if (isValid) etPassword.requestFocus()
            isValid = false
        } else if (password.length < 6) {
            etPassword.error = "La contraseña debe tener al menos 6 caracteres"
            if (isValid) etPassword.requestFocus()
            isValid = false
        }

        if (confirmPassword.isEmpty()) {
            etConfirmPassword.error = "Confirma tu contraseña"
            if (isValid) etConfirmPassword.requestFocus()
            isValid = false
        } else if (password != confirmPassword) {
            etConfirmPassword.error = "Las contraseñas no coinciden"
            if (isValid) etConfirmPassword.requestFocus()
            isValid = false
        }

        return isValid
    }

    private fun saveUserProfile(user: FirebaseUser?, name: String, email: String) {
        user?.let {
            val userData = hashMapOf(
                "name" to name,
                "email" to email,
                "uid" to it.uid,
                "role" to "parent",
                "createdAt" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
                "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
                "profileComplete" to true
            )
            val idp = it.uid
            db.collection("users").document(it.uid)
                .set(userData)
                .addOnSuccessListener {
                    // Guardar datos en SessionManager usando la nueva función
                    SessionManager.saveUserData(
                        this,
                        parentId = idp,
                        email = email,
                        name = name,
                        role = "parent"
                    )

                    // Registrar dispositivo del padre
                    registerParentDevice(idp)

                    showSuccess("¡Cuenta creada exitosamente! 🎉\nBienvenido/a, $name")

                    // Redirigir al home
                    val intent = Intent(this, ParentHomeActivity::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    finish()
                }
                .addOnFailureListener { e ->
                    // Si falla guardar en Firestore, eliminar el usuario de Auth
                    user.delete().addOnCompleteListener {
                        showError("Error al guardar perfil: ${e.message}")
                    }
                }
        }
    }

    private fun registerParentDevice(parentId: String) {
        val manufacturer = android.os.Build.MANUFACTURER.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase() else it.toString()
        }
        val model = android.os.Build.MODEL
        val deviceName = "$manufacturer $model"

        val androidId = android.provider.Settings.Secure.getString(
            contentResolver,
            android.provider.Settings.Secure.ANDROID_ID
        )

        val deviceData = hashMapOf(
            "deviceName" to deviceName,
            "androidId" to androidId,
            "linkedAt" to FieldValue.serverTimestamp(),
            "isActive" to true,
            "lastSeen" to FieldValue.serverTimestamp(),
            "deviceType" to "parent"
        )

        db.collection("parents/$parentId/devices").document(androidId).set(deviceData)
            .addOnSuccessListener {
                Log.d("RegisterActivity", "✅ Dispositivo del padre registrado correctamente")
            }
            .addOnFailureListener { e ->
                Log.e("RegisterActivity", "❌ Error al registrar dispositivo: ${e.message}")
            }
    }

    private fun setLoadingState(isLoading: Boolean) {
        btnRegister.isEnabled = !isLoading
        btnRegister.text = if (isLoading) "Creando cuenta..." else "Crear Cuenta"
    }

    private fun showSuccess(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}