package com.example.controlparental.Parent.Fragment

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.example.controlparental.Parent.Adapter.DashboardViewModel
import com.example.controlparental.R

class DashboardFragment : Fragment() {

    private val viewModel: DashboardViewModel by viewModels()

    private lateinit var tvChildName: TextView
    private lateinit var tvChildStatus: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvUsage: TextView
    private lateinit var tvDeviceName: TextView
    private lateinit var tvDeviceStatus: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_dashboard, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // ---- UI BINDING ----
        tvChildName = view.findViewById(R.id.tvChildName)
        tvChildStatus = view.findViewById(R.id.tvChildStatus)
        tvBattery = view.findViewById(R.id.tvBattery)
        tvUsage = view.findViewById(R.id.tvUsageToday)
        tvDeviceName = view.findViewById(R.id.tvDeviceName)
        tvDeviceStatus = view.findViewById(R.id.tvDeviceStatus)

        val childId = arguments?.getString("childId")
            ?: return Toast.makeText(requireContext(), "Error: no childId", Toast.LENGTH_SHORT).show()

        // ---- OBSERVER ----
        viewModel.data.observe(viewLifecycleOwner) { info ->
            tvChildName.text = info.name
            tvChildStatus.text = "Conectado recientemente"
            tvBattery.text = "Batería: ${info.battery}%"

            tvUsage.text = "${info.totalAppsToday} apps usadas hoy"
            tvDeviceName.text = info.deviceName
            tvDeviceStatus.text = if (info.deviceActive) "Activo" else "Inactivo"
        }

        // ---- LOAD FIREBASE ----
        viewModel.loadDashboard(childId)

    }

}
