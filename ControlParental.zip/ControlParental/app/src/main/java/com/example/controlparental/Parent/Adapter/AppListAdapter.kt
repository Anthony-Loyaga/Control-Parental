package com.example.controlparental.Parent.Adapter

import android.graphics.Color
import android.os.Handler
import android.os.Looper
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.controlparental.R
import com.example.controlparental.entidad.AppItem
import com.google.android.material.switchmaterial.SwitchMaterial

class AppListAdapter(
    private val onToggle: (packageName: String, isBlocked: Boolean) -> Unit,
    private val onAppClick: (packageName: String) -> Unit
) : RecyclerView.Adapter<AppListAdapter.ViewHolder>() {

    private var apps = listOf<AppItem>()
    private var filteredApps = listOf<AppItem>()

    fun updateAppStatus(packageName: String, isBlocked: Boolean) {
        val index = filteredApps.indexOfFirst { it.packageName == packageName }
        if (index != -1) {
            val updatedItem = filteredApps[index].copy(isBlocked = isBlocked)

            val appsIndex = apps.indexOfFirst { it.packageName == packageName }
            if (appsIndex != -1) {
                val mutableApps = apps.toMutableList()
                mutableApps[appsIndex] = updatedItem
                apps = mutableApps
            }

            val mutableFiltered = filteredApps.toMutableList()
            mutableFiltered[index] = updatedItem
            filteredApps = mutableFiltered

            Handler(Looper.getMainLooper()).post {
                notifyItemChanged(index)
            }
        }
    }

    fun updateApps(newApps: List<AppItem>) {
        apps = newApps
        filteredApps = newApps
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        filteredApps = if (query.isEmpty()) {
            apps
        } else {
            apps.filter {
                it.name.lowercase().contains(query.lowercase())
            }
        }
        notifyDataSetChanged()
    }

    fun findByNameOrPackage(query: String): AppItem? {
        val q = query.lowercase()
        return apps.firstOrNull {
            it.name.lowercase() == q || it.packageName.lowercase().contains(q)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_app, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(filteredApps[position], onToggle, onAppClick)
    }

    override fun getItemCount() = filteredApps.size

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val switch = itemView.findViewById<SwitchMaterial>(R.id.appSwitch)
        private var currentPackageName: String? = null

        fun bind(
            app: AppItem,
            onToggle: (String, Boolean) -> Unit,
            onAppClick: (String) -> Unit
        ) {
            currentPackageName = app.packageName

            val appName = itemView.findViewById<TextView>(R.id.tvAppName)
            val lastUsedText = itemView.findViewById<TextView>(R.id.tvAppCategory)
            val usage = itemView.findViewById<TextView>(R.id.tvUsage)
            val statusText = itemView.findViewById<TextView>(R.id.tvStatus)
            val activeText = itemView.findViewById<TextView>(R.id.tvActive)
            val icon = itemView.findViewById<ImageView>(R.id.ivAppIcon)

            appName.text = app.name
            lastUsedText.text = formatLastUsed(app.lastActive)
            usage.text = "${app.timeUsedToday} min hoy"

            if (app.isBlocked) {
                statusText.text = "Bloqueada"
                statusText.setTextColor(Color.RED)
                switch.isChecked = false
            } else {
                statusText.text = "Permitida"
                statusText.setTextColor(Color.GREEN)
                switch.isChecked = true
            }

            if (app.isActive) {
                activeText.text = "En uso ahora"
                activeText.setTextColor(Color.BLUE)
            } else {
                activeText.text = ""
            }

            if (!app.iconUrl.isNullOrBlank()) {
                Glide.with(itemView.context)
                    .load(app.iconUrl)
                    .placeholder(R.drawable.ic_launcher_foreground)
                    .into(icon)
            } else {
                icon.setImageResource(R.drawable.ic_launcher_foreground)
            }

            switch.setOnCheckedChangeListener(null)
            switch.setOnCheckedChangeListener { _, isChecked ->
                val pkg = currentPackageName ?: return@setOnCheckedChangeListener
                onToggle(pkg, !isChecked)
            }

            itemView.setOnClickListener {
                onAppClick(app.packageName)
            }
        }

        private fun formatLastUsed(lastActive: Long): String {
            if (lastActive == 0L) return "Nunca usada"

            val diff = System.currentTimeMillis() - lastActive
            val minutes = diff / 60000
            val hours = minutes / 60
            val days = hours / 24

            return when {
                minutes < 1 -> "Hace unos segundos"
                minutes < 60 -> "Hace $minutes minutos"
                hours < 24 -> "Hace ${hours}h ${minutes % 60}m"
                else -> "Hace ${days} día(s)"
            }
        }
    }
}
