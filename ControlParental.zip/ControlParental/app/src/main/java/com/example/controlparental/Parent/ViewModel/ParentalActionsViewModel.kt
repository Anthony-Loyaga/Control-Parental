package com.example.controlparental.Parent.ViewModel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class ParentalActionsViewModel : ViewModel() {

    // → Desbloquear apps
    private val _unblockApp = MutableLiveData<String?>()
    val unblockApp: LiveData<String?> get() = _unblockApp

    fun unblockApp(packageOrName: String) {
        _unblockApp.value = packageOrName
    }

    // → Establecer límite de tiempo
    private val _setLimit = MutableLiveData<Pair<String, Int>?>()
    val setLimit: LiveData<Pair<String, Int>?> get() = _setLimit

    fun setTimeLimit(packageOrName: String, minutes: Int) {
        _setLimit.value = Pair(packageOrName, minutes)
    }

    // → Seleccionar hijo
    private val _selectChild = MutableLiveData<String?>()
    val selectChild: LiveData<String?> get() = _selectChild

    fun selectChild(name: String) {
        _selectChild.value = name
    }
    fun setAppLimit(packageName: String, minutes: Int) {
        _setLimit.value = packageName to minutes
    }
}
