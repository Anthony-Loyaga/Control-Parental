package com.example.controlparental.Parent.Adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.controlparental.databinding.ItemChatMessageBinding

data class ChatMessage(
    val sender: String,   // "Tú" o "AI"
    val message: String
)

class ChatAdapter(
    private val messages: MutableList<ChatMessage>
) : RecyclerView.Adapter<ChatAdapter.ChatViewHolder>() {

    inner class ChatViewHolder(val binding: ItemChatMessageBinding)
        : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ChatViewHolder {
        val binding = ItemChatMessageBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ChatViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ChatViewHolder, position: Int) {
        val item = messages[position]

        holder.binding.tvSender.text = item.sender
        holder.binding.tvMessage.text = item.message
    }

    override fun getItemCount(): Int = messages.size

    fun addMessage(sender: String, message: String) {
        messages.add(ChatMessage(sender, message))
        notifyItemInserted(messages.size - 1)
    }
}
