package com.example.controlparental.Parent

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.controlparental.R
import com.example.controlparental.utils.SessionManager
import com.google.android.material.button.MaterialButton
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class ParentProfileFragment : Fragment() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var tvUserName: TextView
    private lateinit var tvUserEmail: TextView
    private lateinit var btnLogout: MaterialButton

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.frame_parent_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        initViews(view)
        loadUserData()
        setupClickListeners()
    }

    private fun initViews(view: View) {
        tvUserName = view.findViewById(R.id.tvUserName)
        tvUserEmail = view.findViewById(R.id.tvUserEmail)
        btnLogout = view.findViewById(R.id.btnLogout)

        // Si tienes un botón de back en el fragment, lo manejamos diferente
        view.findViewById<View>(R.id.btnBack)?.setOnClickListener {
            // Manejar navegación hacia atrás si es necesario
            requireActivity().onBackPressed()
        }
    }

    private fun loadUserData() {
        val currentUser = auth.currentUser
        currentUser?.let { user ->
            // Mostrar email desde Firebase Auth
            tvUserEmail.text = user.email

            // Intentar cargar desde SessionManager primero
            SessionManager.getUserName(requireContext())?.let { name ->
                if (name.isNotEmpty()) {
                    tvUserName.text = name
                    return
                }
            }

            // Si no hay en SessionManager, cargar desde Firestore
            db.collection("users").document(user.uid)
                .get()
                .addOnSuccessListener { document ->
                    if (document.exists()) {
                        val name = document.getString("name") ?: "Usuario"
                        tvUserName.text = name
                        // Guardar en SessionManager para futuro uso
                        SessionManager.saveUserName(requireContext(), name)
                    } else {
                        tvUserName.text = user.displayName ?: "Usuario"
                    }
                }
                .addOnFailureListener {
                    tvUserName.text = user.displayName ?: "Usuario"
                }
        }
    }

    private fun setupClickListeners() {
        // Cerrar sesión
        btnLogout.setOnClickListener {
            showLogoutConfirmation()
        }

        // Configuración de cuenta
        requireView().findViewById<View>(R.id.btnAccountSettings).setOnClickListener {
            openAccountSettings()
        }

        // Notificaciones
        requireView().findViewById<View>(R.id.btnNotifications).setOnClickListener {
            showComingSoon("Notificaciones")
        }

        // Seguridad - Cambio de contraseña
        requireView().findViewById<View>(R.id.btnSecurity).setOnClickListener {
            showChangePasswordDialog()
        }

        // Cambio de contraseña de hijo
        requireView().findViewById<View>(R.id.btnChildPassword).setOnClickListener {
            showChildPasswordResetDialog()
        }

        // Ayuda y soporte
        requireView().findViewById<View>(R.id.btnHelpSupport).setOnClickListener {
            showHelpSupportDialog()
        }
    }

    private fun openAccountSettings() {
        val intent = Intent(requireContext(), AccountSettingsActivity::class.java)
        startActivity(intent)
    }

    private fun showLogoutConfirmation() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Cerrar Sesión")
            .setMessage("¿Estás seguro de que quieres cerrar sesión?")
            .setPositiveButton("Sí, cerrar sesión") { dialog, _ ->
                performLogout()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(R.drawable.ic_shield)
            .show()
    }

    private fun performLogout() {
        // Cerrar sesión en Firebase
        auth.signOut()

        // Limpiar datos de sesión
        SessionManager.clear(requireContext())

        // Redirigir al login
        val intent = Intent(requireContext(), LoginActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        }
        startActivity(intent)
        requireActivity().finish()

        Toast.makeText(requireContext(), "Sesión cerrada exitosamente", Toast.LENGTH_SHORT).show()
    }

    private fun showChangePasswordDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Cambiar Contraseña")
            .setMessage("Se enviará un enlace a tu correo electrónico para restablecer tu contraseña.")
            .setPositiveButton("Enviar Enlace") { dialog, _ ->
                sendPasswordResetEmail()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(R.drawable.ic_shield)
            .show()
    }

    private fun sendPasswordResetEmail() {
        val user = auth.currentUser
        user?.email?.let { email ->
            auth.sendPasswordResetEmail(email)
                .addOnCompleteListener { task ->
                    if (task.isSuccessful) {
                        Toast.makeText(
                            requireContext(),
                            "Enlace enviado a $email",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        Toast.makeText(
                            requireContext(),
                            "Error al enviar el enlace: ${task.exception?.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        } ?: run {
            Toast.makeText(requireContext(), "No se pudo obtener tu correo electrónico", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showChildPasswordResetDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Restablecer Contraseña de Hijo")
            .setMessage("Selecciona el hijo al que quieres enviar el enlace de restablecimiento de contraseña.")
            .setPositiveButton("Continuar") { dialog, _ ->
                showChildSelectionDialog()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(R.drawable.ic_shield)
            .show()
    }

    private fun showChildSelectionDialog() {
        val parentId = auth.currentUser?.uid ?: return

        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .get()
            .addOnSuccessListener { documents ->
                val children = mutableListOf<String>()
                documents.forEach { document ->
                    val childId = document.getString("childId")
                    val childName = document.getString("childName") ?: "Hijo"
                    children.add("$childName ($childId)")
                }

                if (children.isEmpty()) {
                    Toast.makeText(requireContext(), "No tienes hijos vinculados", Toast.LENGTH_SHORT).show()
                    return@addOnSuccessListener
                }

                MaterialAlertDialogBuilder(requireContext())
                    .setTitle("Seleccionar Hijo")
                    .setItems(children.toTypedArray()) { dialog, which ->
                        val selectedChild = documents.documents[which]
                        val childId = selectedChild.getString("childId")
                        val childEmail = selectedChild.getString("childEmail")

                        childId?.let {
                            sendChildPasswordResetEmail(it, childEmail)
                        }
                        dialog.dismiss()
                    }
                    .setNegativeButton("Cancelar") { dialog, _ ->
                        dialog.dismiss()
                    }
                    .show()
            }
            .addOnFailureListener { e ->
                Toast.makeText(requireContext(), "Error al cargar hijos: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun sendChildPasswordResetEmail(childId: String, childEmail: String?) {
        if (childEmail.isNullOrEmpty()) {
            db.collection("users").document(childId)
                .get()
                .addOnSuccessListener { document ->
                    val email = document.getString("email")
                    if (email != null) {
                        sendResetEmailToChild(email)
                    } else {
                        Toast.makeText(requireContext(), "No se pudo obtener el email del hijo", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            sendResetEmailToChild(childEmail)
        }
    }

    private fun sendResetEmailToChild(email: String) {
        auth.sendPasswordResetEmail(email)
            .addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    Toast.makeText(
                        requireContext(),
                        "Enlace de restablecimiento enviado a $email",
                        Toast.LENGTH_LONG
                    ).show()
                } else {
                    Toast.makeText(
                        requireContext(),
                        "Error al enviar el enlace: ${task.exception?.message}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
    }

    private fun showHelpSupportDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Ayuda y Soporte")
            .setMessage("¿En qué podemos ayudarte?")
            .setPositiveButton("Contactar Soporte") { dialog, _ ->
                openSupportContact()
                dialog.dismiss()
            }
            .setNeutralButton("Preguntas Frecuentes") { dialog, _ ->
                openFAQ()
                dialog.dismiss()
            }
            .setNegativeButton("Cancelar") { dialog, _ ->
                dialog.dismiss()
            }
            .setIcon(R.drawable.ic_shield)
            .show()
    }

    private fun openSupportContact() {
        val emailIntent = Intent(Intent.ACTION_SEND).apply {
            type = "message/rfc822"
            putExtra(Intent.EXTRA_EMAIL, arrayOf("soporte@familyguard.com"))
            putExtra(Intent.EXTRA_SUBJECT, "Soporte - FamilyGuard")
            putExtra(Intent.EXTRA_TEXT, "Hola, necesito ayuda con...")
        }

        try {
            startActivity(Intent.createChooser(emailIntent, "Enviar correo..."))
        } catch (ex: android.content.ActivityNotFoundException) {
            Toast.makeText(requireContext(), "No hay clientes de email instalados", Toast.LENGTH_SHORT).show()
        }
    }

    private fun openFAQ() {
        showComingSoon("Preguntas Frecuentes")
    }

    private fun showComingSoon(feature: String) {
        Toast.makeText(
            requireContext(),
            "$feature - Próximamente",
            Toast.LENGTH_SHORT
        ).show()
    }
}