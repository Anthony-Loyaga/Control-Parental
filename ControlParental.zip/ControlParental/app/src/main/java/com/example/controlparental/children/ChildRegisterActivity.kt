package com.example.controlparental.children

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class ChildRegisterActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth
    private lateinit var db: FirebaseFirestore
    private lateinit var spinnerGender: Spinner
    private lateinit var etBirthDate: EditText

    private val calendar = Calendar.getInstance()
    private var selectedBirthDate: Calendar? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_register)

        auth = FirebaseAuth.getInstance()
        db = FirebaseFirestore.getInstance()

        val parentId = intent.getStringExtra("parentId") ?: run {
            Toast.makeText(this, "Error: no se recibió el ID del padre", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        // Configurar Spinner de género
        setupGenderSpinner()

        // Configurar el campo de fecha de nacimiento
        setupDatePicker()

        findViewById<Button>(R.id.btnRegister).setOnClickListener {
            registerChild(parentId)
        }
    }

    private fun setupGenderSpinner() {
        spinnerGender = findViewById(R.id.spinnerGender)
        val genders = arrayOf("Seleccionar género", "Masculino", "Femenino", "Otro", "Prefiero no decir")
        val adapter = ArrayAdapter(this, R.layout.spinner_item, genders)
        adapter.setDropDownViewResource(R.layout.spinner_dropdown_item)
        spinnerGender.adapter = adapter
    }

    private fun setupDatePicker() {
        etBirthDate = findViewById(R.id.etBirthDate)

        // Hacer que el campo sea clickeable para abrir el calendario
        etBirthDate.setOnClickListener {
            showDatePicker()
        }

        // También hacer clickeable el icono del calendario (manejado por el TextInputLayout)
    }

    private fun showDatePicker() {
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)

        val datePickerDialog = DatePickerDialog(
            this,
            { _, selectedYear, selectedMonth, selectedDay ->
                // Crear una nueva fecha seleccionada
                selectedBirthDate = Calendar.getInstance().apply {
                    set(selectedYear, selectedMonth, selectedDay)
                }

                // Formatear la fecha para mostrar
                val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                etBirthDate.setText(sdf.format(selectedBirthDate!!.time))

                // Calcular y mostrar la edad automáticamente
                calculateAndDisplayAge()
            },
            year, month, day
        )

        // Establecer fecha máxima como hoy (no puede nacer en el futuro)
        datePickerDialog.datePicker.maxDate = calendar.timeInMillis

        // Establecer fecha mínima (por ejemplo, 18 años atrás para niños)
        val minDate = Calendar.getInstance().apply {
            add(Calendar.YEAR, -18)
        }
        datePickerDialog.datePicker.minDate = minDate.timeInMillis

        datePickerDialog.show()
    }

    private fun calculateAndDisplayAge(): Int {
        return if (selectedBirthDate != null) {
            val today = Calendar.getInstance()
            var age = today.get(Calendar.YEAR) - selectedBirthDate!!.get(Calendar.YEAR)

            // Verificar si ya pasó el cumpleaños este año
            if (today.get(Calendar.DAY_OF_YEAR) < selectedBirthDate!!.get(Calendar.DAY_OF_YEAR)) {
                age--
            }

            // Mostrar la edad en un Toast o podrías mostrarla en un TextView
            Toast.makeText(this, "Edad calculada: $age años", Toast.LENGTH_SHORT).show()
            age
        } else {
            -1
        }
    }

    private fun calculateAge(birthDate: Calendar): Int {
        val today = Calendar.getInstance()
        var age = today.get(Calendar.YEAR) - birthDate.get(Calendar.YEAR)

        // Verificar si ya pasó el cumpleaños este año
        if (today.get(Calendar.DAY_OF_YEAR) < birthDate.get(Calendar.DAY_OF_YEAR)) {
            age--
        }

        return age
    }

    private fun registerChild(parentId: String) {
        Log.d("ChildRegister", "parentId recibido: '$parentId'")
        if (parentId.isEmpty()) {
            Toast.makeText(this, "ID del padre está vacío", Toast.LENGTH_SHORT).show()
            return
        }

        // Obtener datos de los campos
        val name = findViewById<EditText>(R.id.etName).text.toString().trim()
        val lastName = findViewById<EditText>(R.id.etLastName).text.toString().trim()
        val email = findViewById<EditText>(R.id.etEmail).text.toString().trim()
        val password = findViewById<EditText>(R.id.etPassword).text.toString()
        val confirmPassword = findViewById<EditText>(R.id.etConfirmPassword).text.toString()
        val gender = spinnerGender.selectedItem.toString()

        // Validaciones
        if (name.isEmpty() || lastName.isEmpty() || email.isEmpty() ||
            password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        if (selectedBirthDate == null) {
            Toast.makeText(this, "Selecciona la fecha de nacimiento", Toast.LENGTH_SHORT).show()
            return
        }

        if (gender == "Seleccionar género") {
            Toast.makeText(this, "Selecciona un género", Toast.LENGTH_SHORT).show()
            return
        }

        if (password != confirmPassword) {
            Toast.makeText(this, "Las contraseñas no coinciden", Toast.LENGTH_SHORT).show()
            return
        }

        if (password.length < 6) {
            Toast.makeText(this, "La contraseña debe tener al menos 6 caracteres", Toast.LENGTH_SHORT).show()
            return
        }

        // Calcular la edad a partir de la fecha de nacimiento
        val age = calculateAge(selectedBirthDate!!)

        // Validar edad (entre 3 y 18 años)
        if (age < 3 || age > 18) {
            Toast.makeText(this, "La edad debe estar entre 3 y 18 años", Toast.LENGTH_SHORT).show()
            return
        }

        // Mostrar progreso
        findViewById<Button>(R.id.btnRegister).text = "Registrando..."
        findViewById<Button>(R.id.btnRegister).isEnabled = false

        // Paso 1: Crear cuenta en Firebase Authentication
        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val childId = auth.currentUser!!.uid
                    val fullName = "$name $lastName"

                    // Formatear la fecha para guardar
                    val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
                    val birthDateString = sdf.format(selectedBirthDate!!.time)

                    // Paso 2: Guardar datos del niño en 'users' con todos los campos
                    val childData = hashMapOf(
                        "name" to name,
                        "lastName" to lastName,
                        "fullName" to fullName,
                        "email" to email,
                        "birthDate" to birthDateString,
                        "age" to age, // Calculamos la edad y la guardamos como número
                        "gender" to gender,
                        "parentId" to parentId,
                        "role" to "child",
                        "createdAt" to FieldValue.serverTimestamp(),
                        "updatedAt" to FieldValue.serverTimestamp()
                    )

                    db.collection("users").document(childId).set(childData)
                        .addOnSuccessListener {
                            // Paso 3: Crear relación en 'guardianships' con ID predecible
                            val guardianshipId = "${parentId}_${childId}"
                            val guardianshipData = hashMapOf(
                                "parentId" to parentId,
                                "childId" to childId,
                                "childName" to fullName,
                                "childAge" to age,
                                "status" to "active",
                                "linkedAt" to FieldValue.serverTimestamp()
                            )

                            db.collection("guardianships").document(guardianshipId).set(guardianshipData)
                                .addOnSuccessListener {
                                    Log.d("ChildRegister", "✅ Guardianships creado con ID: $guardianshipId")

                                    // Registrar dispositivo del niño
                                    registerChildDevice(childId)

                                    Toast.makeText(
                                        this,
                                        "¡Registro exitoso! 🎉\nAhora estás vinculado al padre.",
                                        Toast.LENGTH_LONG
                                    ).show()

                                    val intent = Intent(this, ChildHomeActivity::class.java).apply {
                                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                                    }
                                    startActivity(intent)
                                    finish()
                                }
                                .addOnFailureListener { e ->
                                    Log.e("ChildRegister", "❌ Error al crear guardianships", e)
                                    // Rollback: eliminar usuario de Auth y datos de Firestore
                                    auth.currentUser?.delete()
                                    db.collection("users").document(childId).delete()
                                    resetButton()
                                    Toast.makeText(
                                        this,
                                        "Error al vincular con el padre: ${e.message}",
                                        Toast.LENGTH_LONG
                                    ).show()
                                }
                        }
                        .addOnFailureListener { e ->
                            // Rollback: eliminar usuario de Auth
                            auth.currentUser?.delete()
                            resetButton()
                            Toast.makeText(
                                this,
                                "Error al guardar perfil: ${e.message}",
                                Toast.LENGTH_SHORT
                            ).show()
                        }
                } else {
                    resetButton()
                    val message = task.exception?.message ?: "Error desconocido"
                    Toast.makeText(this, "Error: $message", Toast.LENGTH_LONG).show()
                }
            }
    }

    private fun resetButton() {
        findViewById<Button>(R.id.btnRegister).text = "Registrar y Vincular"
        findViewById<Button>(R.id.btnRegister).isEnabled = true
    }

    private fun registerChildDevice(childId: String) {
        val manufacturer = android.os.Build.MANUFACTURER.replaceFirstChar {
            if (it.isLowerCase()) it.titlecase() else it.toString()
        }
        val model = android.os.Build.MODEL
        val deviceName = "$manufacturer $model"

        val androidId = android.provider.Settings.Secure.getString(
            contentResolver,
            android.provider.Settings.Secure.ANDROID_ID
        )

        val deviceData = hashMapOf(
            "deviceName" to deviceName,
            "androidId" to androidId,
            "linkedAt" to FieldValue.serverTimestamp(),
            "isActive" to true,
            "lastSeen" to FieldValue.serverTimestamp()
        )

        db.collection("children/$childId/devices").document(androidId).set(deviceData)
            .addOnSuccessListener {
                Log.d("ChildRegister", "✅ Dispositivo del niño registrado correctamente")
            }
            .addOnFailureListener { e ->
                Log.e("ChildRegister", "❌ Error al registrar dispositivo: ${e.message}")
            }
    }
}