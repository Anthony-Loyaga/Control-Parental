package com.example.controlparental.children

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.children.ChildLoginActivity
import com.example.controlparental.children.ChildRegisterActivity
import com.example.controlparental.R
import com.google.zxing.integration.android.IntentIntegrator
import org.json.JSONObject

class ChildLandingActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_child_landing)

        findViewById<Button>(R.id.btnScanQr).setOnClickListener {
            startQrScanner()
        }
        findViewById<Button>(R.id.btnLogin).setOnClickListener {
            startActivity(Intent(this, ChildLoginActivity::class.java))
        }
    }

    private fun startQrScanner() {
        IntentIntegrator(this)
            .setDesiredBarcodeFormats(IntentIntegrator.QR_CODE)
            .setCameraId(0)
            .setBeepEnabled(false)
            .initiateScan()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        val result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data)
        if (result != null) {
            if (result.contents == null) {
                Toast.makeText(this, "Escaneo cancelado", Toast.LENGTH_SHORT).show()
            } else {
                try {
                    val json = JSONObject(result.contents)
                    val parentId = json.getString("parentId")
                    val timestamp = json.getLong("timestamp")
                    val ttl = json.getLong("ttl")

                    if (System.currentTimeMillis() - timestamp > ttl) {
                        Toast.makeText(this, "El código ha expirado", Toast.LENGTH_SHORT).show()
                        return
                    }

                    // Ir a registro con el parentId
                    val intent = Intent(this, ChildRegisterActivity::class.java).apply {
                        putExtra("parentId", parentId)
                    }
                    startActivity(intent)
                    finish()

                } catch (e: Exception) {
                    Toast.makeText(this, "Código QR inválido", Toast.LENGTH_SHORT).show()
                }
            }
        } else {
            super.onActivityResult(requestCode, resultCode, data)
        }
    }
}