package com.example.controlparental.Parent

import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.controlparental.R
import com.google.firebase.auth.FirebaseAuth
import com.google.zxing.BarcodeFormat
import com.journeyapps.barcodescanner.BarcodeEncoder
import org.json.JSONObject
import kotlin.math.min

class LinkDeviceActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_link_device)

        val parentId = FirebaseAuth.getInstance().currentUser?.uid
        if (parentId == null) {
            Toast.makeText(this, "Error: no hay sesión activa", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        generateAndDisplayQr(parentId)

        findViewById<Button>(R.id.btnClose).setOnClickListener {
            finish()
        }
    }

    private fun generateAndDisplayQr(parentId: String) {
        val payload = JSONObject().apply {
            put("parentId", parentId)
            put("timestamp", System.currentTimeMillis())
            put("ttl", 300_000) // 5 minutos
        }.toString()

        val imageView = findViewById<ImageView>(R.id.ivQrCode)

        // Espera a que el ImageView esté renderizado para conocer su tamaño real
        imageView.post {
            try {
                val barcodeEncoder = BarcodeEncoder()
                val width = imageView.width
                val height = imageView.height
                val size = min(width, height).coerceAtLeast(400) // tamaño mínimo 400px

                val bitmap = barcodeEncoder.encodeBitmap(payload, BarcodeFormat.QR_CODE, size, size)
                imageView.scaleType = ImageView.ScaleType.FIT_CENTER
                imageView.setImageBitmap(bitmap)
            } catch (e: Exception) {
                Toast.makeText(this, "Error al generar QR", Toast.LENGTH_SHORT).show()
                e.printStackTrace()
            }
        }
    }

}