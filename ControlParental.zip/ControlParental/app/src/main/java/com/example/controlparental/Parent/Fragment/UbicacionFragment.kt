package com.example.controlparental.Parent.Fragment

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import com.example.controlparental.R
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import com.google.android.material.card.MaterialCardView
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.collections.iterator

class UbicacionFragment : Fragment(), OnMapReadyCallback {

    private lateinit var db: FirebaseFirestore
    private lateinit var googleMap: GoogleMap

    // Views
    private lateinit var childrenContainer: LinearLayout
    private lateinit var progressBarMap: ProgressBar
    private lateinit var noLocationContainer: LinearLayout
    private lateinit var locationInfoCard: MaterialCardView
    private lateinit var tvChildName: TextView
    private lateinit var tvAddress: TextView
    private lateinit var tvLastUpdate: TextView
    private lateinit var tvBattery: TextView
    private lateinit var tvAccuracy: TextView
    private lateinit var tvLocationStatus: TextView
    private lateinit var btnRefreshLocation: Button
    private lateinit var btnLocationHistory: Button

    private var currentChildId: String? = null
    private val childMarkers = HashMap<String, Marker>()
    private val childData = HashMap<String, ChildData>()
    private var selectedChildMarker: Marker? = null

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflar el layout sin data binding
        return inflater.inflate(R.layout.fragment_ubicacion, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        Log.d("UbicacionFragment", "🟢 Fragment creado")

        // Inicializar vistas
        initViews(view)

        // Inicializar Firebase
        db = FirebaseFirestore.getInstance()

        // Configurar el mapa
        setupMap()

        // Cargar la lista de hijos
        loadChildren()

        // Configurar listeners de botones
        setupClickListeners()
    }

    private fun initViews(view: View) {
        childrenContainer = view.findViewById(R.id.childrenContainer)
        progressBarMap = view.findViewById(R.id.progressBarMap)
        noLocationContainer = view.findViewById(R.id.noLocationContainer)
        locationInfoCard = view.findViewById(R.id.locationInfoCard)
        tvChildName = view.findViewById(R.id.tvChildName)
        tvAddress = view.findViewById(R.id.tvAddress)
        tvLastUpdate = view.findViewById(R.id.tvLastUpdate)
        tvBattery = view.findViewById(R.id.tvBattery)
        tvAccuracy = view.findViewById(R.id.tvAccuracy)
        tvLocationStatus = view.findViewById(R.id.tvLocationStatus)
        btnRefreshLocation = view.findViewById(R.id.btnRefreshLocation)
        btnLocationHistory = view.findViewById(R.id.btnLocationHistory)
    }

    private fun setupMap() {
        val mapFragment = childFragmentManager.findFragmentById(R.id.mapFragment) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    override fun onMapReady(map: GoogleMap) {
        Log.d("UbicacionFragment", "🗺️ Mapa listo")
        googleMap = map

        // Configurar el mapa
        googleMap.uiSettings.isZoomControlsEnabled = true
        googleMap.uiSettings.isMyLocationButtonEnabled = true
        googleMap.uiSettings.isCompassEnabled = true

        // Listener para clicks en marcadores
        googleMap.setOnMarkerClickListener { marker ->
            onMarkerClick(marker)
            true
        }
    }

    private fun loadChildren() {
        val parentId = FirebaseAuth.getInstance().currentUser?.uid
        if (parentId == null) {
            Log.e("UbicacionFragment", "❌ No hay usuario logueado")
            return
        }

        Log.d("UbicacionFragment", "👨‍👦 Buscando hijos del padre: $parentId")

        progressBarMap.visibility = View.VISIBLE

        db.collection("guardianships")
            .whereEqualTo("parentId", parentId)
            .whereEqualTo("status", "active")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("UbicacionFragment", "❌ Error buscando hijos", error)
                    progressBarMap.visibility = View.GONE
                    return@addSnapshotListener
                }

                val childrenCount = snapshot?.documents?.size ?: 0
                Log.d("UbicacionFragment", "📊 Hijos encontrados: $childrenCount")

                childrenContainer.removeAllViews()
                childData.clear()

                snapshot?.documents?.forEach { document ->
                    val childId = document.getString("childId")
                    childId?.let {
                        getChildInfo(childId)
                    }
                }

                if (childrenCount == 0) {
                    showNoChildrenMessage()
                }
            }
    }

    private fun getChildInfo(childId: String) {
        db.collection("users").document(childId)
            .get()
            .addOnSuccessListener { userDocument ->
                if (userDocument.exists()) {
                    val childName = userDocument.getString("name") ?: "Niño"
                    val childEmail = userDocument.getString("email") ?: ""

                    val data = ChildData(childId, childName, childEmail)
                    childData[childId] = data

                    // Agregar a la UI
                    addChildToContainer(childId, childName)

                    // Escuchar ubicación de este hijo
                    listenToChildLocation(childId, childName)

                } else {
                    Log.e("UbicacionFragment", "❌ No se encontró usuario para: $childId")
                }
            }
            .addOnFailureListener { e ->
                Log.e("UbicacionFragment", "❌ Error obteniendo info del niño", e)
            }
    }

    private fun addChildToContainer(childId: String, childName: String) {
        val childView = LayoutInflater.from(requireContext()).inflate(R.layout.item_child_location, childrenContainer, false)

        // Configurar la vista
        val tvChildInitial = childView.findViewById<TextView>(R.id.tvChildInitial)
        val tvChildName = childView.findViewById<TextView>(R.id.tvChildName)
        val tvChildStatus = childView.findViewById<TextView>(R.id.tvChildStatus)

        tvChildInitial.text = childName.first().toString().uppercase()
        tvChildName.text = childName
        tvChildStatus.text = "Cargando..."
        tvChildStatus.setTextColor(ContextCompat.getColor(requireContext(), android.R.color.darker_gray))

        // Click listener
        childView.setOnClickListener {
            selectChild(childId)
        }

        childrenContainer.addView(childView)
    }

    private fun listenToChildLocation(childId: String, childName: String) {
        Log.d("UbicacionFragment", "📍 Escuchando ubicación de: $childName ($childId)")

        db.collection("children").document(childId)
            .collection("location")
            .document("current")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e("UbicacionFragment", "❌ Error escuchando ubicación", error)
                    updateChildStatus(childId, "Error", Color.RED)
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val latitude = snapshot.getDouble("latitude")
                    val longitude = snapshot.getDouble("longitude")
                    val timestamp = snapshot.getLong("timestamp")
                    val address = snapshot.getString("address") ?: "Ubicación no disponible"
                    val batteryLevel = snapshot.getDouble("batteryLevel") ?: -1.0
                    val accuracy = snapshot.getDouble("accuracy") ?: 0.0

                    Log.d("UbicacionFragment", "📍 Nueva ubicación para $childName: $latitude, $longitude")

                    if (latitude != null && longitude != null) {
                        updateChildStatus(childId, "En línea", Color.GREEN)
                        updateChildMarker(childId, childName, latitude, longitude, address, timestamp, batteryLevel, accuracy)

                        // Si es el primer hijo, seleccionarlo automáticamente
                        if (currentChildId == null) {
                            selectChild(childId)
                        }

                    } else {
                        updateChildStatus(childId, "Sin ubicación", Color.GRAY)
                    }
                } else {
                    Log.w("UbicacionFragment", "⚠️ No hay ubicación disponible para: $childName")
                    updateChildStatus(childId, "Sin ubicación", Color.GRAY)
                    showNoLocationMessage()
                }

                progressBarMap.visibility = View.GONE
            }
    }

    private fun updateChildStatus(childId: String, status: String, color: Int) {
        for (i in 0 until childrenContainer.childCount) {
            val childView = childrenContainer.getChildAt(i)
            val nameView = childView.findViewById<TextView>(R.id.tvChildName)

            if (nameView.text == childData[childId]?.name) {
                val statusView = childView.findViewById<TextView>(R.id.tvChildStatus)
                statusView.text = status
                statusView.setTextColor(color)
                break
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateChildMarker(
        childId: String,
        childName: String,
        lat: Double,
        lng: Double,
        address: String,
        timestamp: Long?,
        batteryLevel: Double,
        accuracy: Double
    ) {
        val location = LatLng(lat, lng)
        val timeText = if (timestamp != null) formatTimestamp(timestamp) else "Desconocido"
        val batteryText = if (batteryLevel > 0) "${batteryLevel.toInt()}%" else "N/A"
        val accuracyText = if (accuracy > 0) "${accuracy.toInt()}m" else "N/A"

        val snippet = """
            $address
            Actualizado: $timeText
            Batería: $batteryText • Precisión: $accuracyText
        """.trimIndent()

        activity?.runOnUiThread {
            if (childMarkers.containsKey(childId)) {
                // Actualizar marcador existente
                val marker = childMarkers[childId]
                marker?.position = location
                marker?.snippet = snippet
                marker?.title = childName

                // Si este es el niño seleccionado, actualizar la info
                if (childId == currentChildId) {
                    updateLocationInfo(childName, address, timeText, batteryText, accuracyText)
                }

            } else {
                // Crear nuevo marcador
                val marker = googleMap.addMarker(
                    MarkerOptions()
                        .position(location)
                        .title(childName)
                        .snippet(snippet)
                        .icon(BitmapDescriptorFactory.defaultMarker(getColorForChild(childId)))
                )
                if (marker != null) {
                    childMarkers[childId] = marker
                }
                Log.d("UbicacionFragment", "📍 Nuevo marcador: $childName")
            }
        }
    }

    private fun selectChild(childId: String) {
        currentChildId = childId
        val childData = childData[childId] ?: return

        Log.d("UbicacionFragment", "👶 Hijo seleccionado: ${childData.name}")

        // Resaltar el niño seleccionado en la lista
        updateChildSelectionUI(childId)

        // Mostrar información de ubicación
        showLocationInfo()

        // Centrar el mapa en el marcador del niño
        val marker = childMarkers[childId]
        if (marker != null) {
            googleMap.animateCamera(CameraUpdateFactory.newLatLngZoom(marker.position, 15f))

            // Mostrar info del marcador
            marker.showInfoWindow()
            selectedChildMarker = marker

            // Extraer información del snippet para mostrar en el card
            val snippetLines = marker.snippet?.split("\n") ?: emptyList()
            if (snippetLines.size >= 3) {
                val address = snippetLines[0]
                val timeText = snippetLines[1].replace("Actualizado: ", "")
                val batteryAccuracy = snippetLines[2].split(" • ")
                val battery = batteryAccuracy.getOrNull(0)?.replace("Batería: ", "") ?: "N/A"
                val accuracy = batteryAccuracy.getOrNull(1)?.replace("Precisión: ", "") ?: "N/A"

                updateLocationInfo(childData.name, address, timeText, battery, accuracy)
            }
        } else {
            showNoLocationMessage()
        }
    }

    private fun updateChildSelectionUI(selectedChildId: String) {
        for (i in 0 until childrenContainer.childCount) {
            val childView = childrenContainer.getChildAt(i)
            val cardView = childView as MaterialCardView
            val nameView = childView.findViewById<TextView>(R.id.tvChildName)

            val isSelected = childData[selectedChildId]?.name == nameView.text
            if (isSelected) {
                cardView.setCardBackgroundColor(ContextCompat.getColor(requireContext(), R.color.light_purple))
                cardView.strokeColor = ContextCompat.getColor(requireContext(), R.color.purple_500)
                cardView.strokeWidth = 2
            } else {
                cardView.setCardBackgroundColor(Color.WHITE)
                cardView.strokeColor = Color.TRANSPARENT
                cardView.strokeWidth = 0
            }
        }
    }

    @SuppressLint("SetTextI18n")
    private fun updateLocationInfo(childName: String, address: String, timeText: String, battery: String, accuracy: String) {
        tvChildName.text = childName
        tvAddress.text = address
        tvLastUpdate.text = timeText
        tvBattery.text = battery
        tvAccuracy.text = accuracy

        // Actualizar estado (en línea/offline basado en la antigüedad)
        val isOnline = isLocationRecent(timeText)
        tvLocationStatus.text = if (isOnline) "En línea" else "Offline"

        // Configurar color de fondo según el estado
        val backgroundRes = if (isOnline) {
            // Crear drawable programáticamente para online
            R.drawable.bg_online_status
        } else {
            // Crear drawable programáticamente para offline
            R.drawable.bg_offline_status
        }
        tvLocationStatus.setBackgroundResource(backgroundRes)
    }

    private fun isLocationRecent(timeText: String): Boolean {
        // Lógica simple para determinar si la ubicación es reciente
        // (menos de 10 minutos)
        return !timeText.contains("min") || timeText.replace("Hace ", "")
            .replace("min", "").trim().toIntOrNull() ?: 0 < 10
    }

    private fun showLocationInfo() {
        noLocationContainer.visibility = View.GONE
        locationInfoCard.visibility = View.VISIBLE
    }

    private fun showNoLocationMessage() {
        noLocationContainer.visibility = View.VISIBLE
        locationInfoCard.visibility = View.GONE
    }

    private fun showNoChildrenMessage() {
        noLocationContainer.visibility = View.VISIBLE
        // Buscar los TextViews dentro del contenedor
        val textView1 = noLocationContainer.findViewById<TextView>(android.R.id.text1)
        val textView2 = noLocationContainer.findViewById<TextView>(android.R.id.text2)

        textView1?.text = "No tienes hijos agregados"
        textView2?.text = "Agrega hijos para ver sus ubicaciones"
    }

    private fun onMarkerClick(marker: Marker): Boolean {
        // Encontrar qué hijo corresponde a este marcador
        for ((childId, childMarker) in childMarkers) {
            if (childMarker == marker) {
                selectChild(childId)
                break
            }
        }
        return false // Devolver false para mostrar el info window
    }

    private fun setupClickListeners() {
        btnRefreshLocation.setOnClickListener {
            refreshLocations()
        }

        btnLocationHistory.setOnClickListener {
            // TODO: Implementar historial de ubicaciones
            showMessage("Historial de ubicaciones - Próximamente")
        }
    }

    private fun refreshLocations() {
        progressBarMap.visibility = View.VISIBLE
        showMessage("Actualizando ubicaciones...")

        // Forzar actualización recargando los hijos
        loadChildren()
    }

    private fun getColorForChild(childId: String): Float {
        val colors = listOf(
            BitmapDescriptorFactory.HUE_RED,
            BitmapDescriptorFactory.HUE_BLUE,
            BitmapDescriptorFactory.HUE_GREEN,
            BitmapDescriptorFactory.HUE_ORANGE,
            BitmapDescriptorFactory.HUE_VIOLET,
            BitmapDescriptorFactory.HUE_YELLOW,
            BitmapDescriptorFactory.HUE_CYAN,
            BitmapDescriptorFactory.HUE_MAGENTA
        )
        val index = childId.hashCode() % colors.size
        return colors[Math.abs(index)]
    }

    private fun formatTimestamp(timestamp: Long): String {
        return try {
            val now = System.currentTimeMillis()
            val diff = now - timestamp
            val minutes = diff / (1000 * 60)

            when {
                minutes < 1 -> "Hace un momento"
                minutes < 60 -> "Hace ${minutes.toInt()} min"
                minutes < 1440 -> "Hace ${(minutes / 60).toInt()} h"
                else -> SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(timestamp))
            }
        } catch (e: Exception) {
            "Desconocido"
        }
    }

    private fun showMessage(message: String) {
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }

    // Data class para almacenar info de los hijos
    data class ChildData(
        val id: String,
        val name: String,
        val email: String
    )
}