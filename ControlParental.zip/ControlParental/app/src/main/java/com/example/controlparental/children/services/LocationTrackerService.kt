package com.example.controlparental.children.services

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.location.Location
import android.os.BatteryManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.controlparental.R
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationAvailability
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.Date
import java.util.HashMap
import java.util.Locale

class LocationTrackerService : Service() {

    private lateinit var db: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private lateinit var locationCallback: LocationCallback

    private var currentChildId: String? = null
    private var isTracking = false

    companion object {
        private const val NOTIFICATION_ID = 124
        private const val LOCATION_UPDATE_INTERVAL = 10000L // 10 segundos
        private const val FASTEST_LOCATION_INTERVAL = 5000L // 5 segundos
    }

    override fun onCreate() {
        super.onCreate()
        Log.d("LocationTracker", "🟢 Servicio de ubicación creado")

        initComponents()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d("LocationTracker", "🚀 Iniciando servicio de ubicación")

        startForegroundService()
        startLocationTracking()

        return START_STICKY
    }

    private fun initComponents() {
        db = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        currentChildId = auth.currentUser?.uid

        createLocationRequest()
        createLocationCallback()
    }

    @SuppressLint("MissingPermission")
    private fun createLocationRequest() {
        locationRequest = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            LocationRequest.Builder(
                Priority.PRIORITY_HIGH_ACCURACY,
                LOCATION_UPDATE_INTERVAL
            )
                .setMinUpdateIntervalMillis(FASTEST_LOCATION_INTERVAL)
                .setWaitForAccurateLocation(true)
                .build()
        } else {
            @Suppress("DEPRECATION")
            LocationRequest.create().apply {
                priority = LocationRequest.PRIORITY_HIGH_ACCURACY
                interval = LOCATION_UPDATE_INTERVAL
                fastestInterval = FASTEST_LOCATION_INTERVAL

                // Esto es deprecado pero válido
                @Suppress("DEPRECATION")
                setWaitForAccurateLocation(true)
            }
        }
    }

    private fun createLocationCallback() {
        locationCallback = object : LocationCallback() {
            override fun onLocationResult(locationResult: LocationResult) {
                super.onLocationResult(locationResult)
                locationResult.lastLocation?.let { location ->
                    Log.d("LocationTracker", "📍 Nueva ubicación obtenida: ${location.latitude}, ${location.longitude}")
                    saveLocationToFirebase(location)
                }
            }

            override fun onLocationAvailability(locationAvailability: LocationAvailability) {
                super.onLocationAvailability(locationAvailability)
                if (!locationAvailability.isLocationAvailable) {
                    Log.w("LocationTracker", "⚠️ Ubicación no disponible")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun startLocationTracking() {
        if (!hasLocationPermission()) {
            Log.e("LocationTracker", "❌ Sin permisos de ubicación")
            stopSelf()
            return
        }

        if (isTracking) {
            Log.d("LocationTracker", "📍 El tracking ya está activo")
            return
        }

        try {
            fusedLocationClient.requestLocationUpdates(
                locationRequest,
                locationCallback,
                Looper.getMainLooper()
            )

            isTracking = true
            Log.d("LocationTracker", "✅ Tracking de ubicación iniciado - Intervalo: 10 segundos")

            // También obtener ubicación inmediata
            getLastKnownLocation()

        } catch (e: Exception) {
            Log.e("LocationTracker", "❌ Error iniciando tracking", e)
            stopSelf()
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLastKnownLocation() {
        if (!hasLocationPermission()) return

        fusedLocationClient.lastLocation
            .addOnSuccessListener { location ->
                location?.let {
                    Log.d("LocationTracker", "📍 Última ubicación conocida: ${it.latitude}, ${it.longitude}")
                    saveLocationToFirebase(it)
                }
            }
            .addOnFailureListener { e ->
                Log.e("LocationTracker", "❌ Error obteniendo última ubicación", e)
            }
    }

    private fun saveLocationToFirebase(location: Location) {
        val childId = currentChildId ?: return

        val locationData = hashMapOf<String, Any>(
            "latitude" to location.latitude,
            "longitude" to location.longitude,
            "timestamp" to System.currentTimeMillis(),
            "accuracy" to (location.accuracy),
            "batteryLevel" to getBatteryLevel(),
            "source" to (location.provider ?: "unknown"),
            "speed" to (location.speed * 3.6), // km/h
            "altitude" to location.altitude
        )

        Log.d("LocationTracker", "💾 Guardando ubicación en Firebase...")

        // Guardar ubicación actual
        db.collection("children").document(childId)
            .collection("location")
            .document("current")
            .set(locationData)
            .addOnSuccessListener {
                Log.d("LocationTracker", "✅ Ubicación guardada: ${location.latitude}, ${location.longitude}")

                // También guardar en historial (opcional, para no saturar la base de datos)
                saveToLocationHistory(childId, locationData)

            }
            .addOnFailureListener { e ->
                Log.e("LocationTracker", "❌ Error guardando ubicación", e)
            }
    }

    private fun saveToLocationHistory(childId: String, locationData: HashMap<String, Any>) {
        // Guardar solo una vez cada 5 minutos en el historial para no saturar
        val currentTime = System.currentTimeMillis()
        val fiveMinutesAgo = currentTime - (5 * 60 * 1000)

        // Verificar si ya guardamos una ubicación recientemente
        db.collection("children").document(childId)
            .collection("locationHistory")
            .orderBy("timestamp", Query.Direction.DESCENDING)
            .limit(1)
            .get()
            .addOnSuccessListener { querySnapshot ->
                val shouldSave = if (!querySnapshot.isEmpty) {
                    val lastLocation = querySnapshot.documents[0]
                    val lastTimestamp = lastLocation.getLong("timestamp") ?: 0L
                    currentTime - lastTimestamp > (5 * 60 * 1000) // 5 minutos
                } else {
                    true
                }

                if (shouldSave) {
                    val historyDocId = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(
                        Date()
                    )

                    db.collection("children").document(childId)
                        .collection("locationHistory")
                        .document(historyDocId)
                        .set(locationData)
                        .addOnSuccessListener {
                            Log.d("LocationTracker", "📝 Ubicación guardada en historial")
                        }
                        .addOnFailureListener { e ->
                            Log.e("LocationTracker", "❌ Error guardando en historial", e)
                        }
                }
            }
    }

    private fun getBatteryLevel(): Float {
        return try {
            val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            if (level != -1 && scale != -1) {
                (level * 100 / scale.toFloat())
            } else {
                -1f
            }
        } catch (e: Exception) {
            -1f
        }
    }

    private fun hasLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(
                    this,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                ) == PackageManager.PERMISSION_GRANTED
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "location_tracker_channel",
                "Seguimiento de Ubicación",
                NotificationManager.IMPORTANCE_LOW
            )
            channel.description = "Monitoreando ubicación en segundo plano"
            channel.setShowBadge(false)

            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }


    private fun startForegroundService() {
        val notification = NotificationCompat.Builder(this, "location_tracker_channel")
            .setContentTitle("📍 Control Parental")
            .setContentText("Monitoreando ubicación...")
            .setSmallIcon(getNotificationIcon())
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true)
            .setAutoCancel(false)
            .setShowWhen(false)
            .setSilent(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
        Log.d("LocationTracker", "✅ Servicio en primer plano iniciado")
    }

    private fun getNotificationIcon(): Int {
        return try {
            // Intenta usar tu icono personalizado
            R.drawable.ic_ubicacion
        } catch (e: Exception) {
            // Si no existe, usa un icono del sistema
            android.R.drawable.ic_dialog_map
        }
    }

    private fun stopLocationTracking() {
        if (isTracking) {
            fusedLocationClient.removeLocationUpdates(locationCallback)
            isTracking = false
            Log.d("LocationTracker", "🛑 Tracking de ubicación detenido")
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopLocationTracking()
        Log.d("LocationTracker", "🛑 Servicio de ubicación destruido")
    }

    override fun onBind(intent: Intent?): IBinder? = null
}